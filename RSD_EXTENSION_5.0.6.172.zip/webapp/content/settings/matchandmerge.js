function RSDMatchAndMerge()
{
}

new RSDMatchAndMerge();

RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MATCH = true;
RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MERGE = true;
RSDMatchAndMerge.VALID_MANAGED_SYSTEM_MATCH = true;
RSDMatchAndMerge.VALID_IPADDRESSES = true;
RSDMatchAndMerge.VALID_AGENT_PORT = true;

RSDMatchAndMerge.validate = function ()
{
    RSDMatchAndMerge.validateMatchDetectedSystems();
    RSDMatchAndMerge.validateMergeDetectedSystems();
    RSDMatchAndMerge.validateMatchManagedSystems();
    RSDMatchAndMerge.validateAgentPort();

    var dsip = $("ds.match.ip").checked;
    var msip = $("ms.match.ip").checked;
    var iprange = $("textarea.iprange");
    if (dsip || msip)
    {
        OrionCore.setEnabled(iprange, true);
        RSDMatchAndMerge.VALID_IPADDRESSES = RSDMatchAndMerge.validateIPRange();
        var val = RSDMatchAndMerge.trimIncludingReturnChar(iprange.value);
        if (val.length == 0)
        {
            RSDMatchAndMerge.VALID_IPADDRESSES = false;
        }
    }
    else
    {
        OrionCore.setEnabled(iprange, false);        
        RSDMatchAndMerge.VALID_IPADDRESSES = true;
    }

    OrionCore.setEnabledById("saveButton",
        RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MATCH &
        RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MERGE &
        RSDMatchAndMerge.VALID_MANAGED_SYSTEM_MATCH &
        RSDMatchAndMerge.VALID_IPADDRESSES &
        RSDMatchAndMerge.VALID_AGENT_PORT
        );
}

RSDMatchAndMerge.validateMatchDetectedSystems = function ()
{
    var mac = $("ds.match.mac").checked;
    var hndn = $("ds.match.hostnamedomain").checked;
    var fqdns = $("ds.match.fqdns").checked;
    var ip = $("ds.match.ip").checked;
    var hn = $("ds.match.hostname").checked;

    RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MATCH = (mac | hndn | fqdns | ip | hn);
}

RSDMatchAndMerge.validateMergeDetectedSystems = function ()
{
    RSDMatchAndMerge.VALID_DETECTED_SYSTEM_MERGE = true;
}

RSDMatchAndMerge.validateMatchManagedSystems = function ()
{
    var mac = $("ms.match.mac").checked;
    var hndn = $("ms.match.hostnamedomain").checked;
    var fqdns = $("ms.match.fqdns").checked;
    var ip = $("ms.match.ip").checked;
    var hn = $("ms.match.hostname").checked;

    RSDMatchAndMerge.VALID_MANAGED_SYSTEM_MATCH = (mac | hndn | fqdns | ip | hn);
}

RSDMatchAndMerge.validateIPRange = function ()
{
    if ($("ip.range.error"))
    {
        $("ip.range.error").style.display = "none";
    }
    RSDMatchAndMerge.VALID_IPADDRESSES = true;

    var iprange = $("textarea.iprange");
    var rangeList = iprange.value;

    if (rangeList && rangeList.length > 0)
    {
        var ranges = rangeList.split(/[\r\n]/);

        for (var i = 0; i < ranges.length; i++)
        {
            var range = OrionCore.trim(ranges[i]);
            // Minimum valid range is length of 0.0.0.0-0.0.0.0
            if (range.length > 14)
            {
                var addrs = range.split('-');
                if (addrs.length != 2)
                {
                    RSDMatchAndMerge.VALID_IPADDRESSES = false;
                    return false;
                }

                var addr1 = RSDMatchAndMerge.trimIncludingReturnChar(addrs[0]);
                var addr2 = RSDMatchAndMerge.trimIncludingReturnChar(addrs[1]);

                if (!OrionValidate.isValidIPv4String(addr1) || !OrionValidate.isValidIPv4String(addr2))
                {
                    RSDMatchAndMerge.VALID_IPADDRESSES = false;
                    if (!OrionValidate.isValidIPv6String(addr1) || !OrionValidate.isValidIPv6String(addr2))
                    {
                        RSDMatchAndMerge.VALID_IPADDRESSES = false;
                        return false;
                    }
                }
            }
            else
            {
                var len = RSDMatchAndMerge.trimIncludingReturnChar(range);
                if (len.length > 0)
                    return false;
            }
        }
    }
    else
    {
        RSDMatchAndMerge.VALID_IPADDRESSES = false;
        return false;
    }

    return true;
}

RSDMatchAndMerge.trimIncludingReturnChar = function (source)
{
    var str = OrionCore.trim(source);

    while (str.substring(str.length-1, str.length) == "\n")
    {
        str = str.substring(0, str.length -1);
    }
    while (str.substring(str.length-1, str.length) == "\r")
    {
        str = str.substring(0, str.length -1);
    }
    return str;
}

RSDMatchAndMerge.validateAgentPort = function ()
{
    if ($("agent.port.error"))
    {
        $("agent.port.error").style.display = "none";
    }
    RSDMatchAndMerge.VALID_AGENT_PORT = true;

    var portList = OrionCore.trim($("agent.port.box").value);
    if (portList.length > 0)
    {
        var ports = portList.split(",");
        for (var i = 0; i < ports.length; i++)
        {
            var port = OrionCore.trim(ports[i]);
            if (!OrionValidate.isIntBetween(port, 1, 65535))
            {
                RSDMatchAndMerge.VALID_AGENT_PORT = false;
                return false;
            }
        }
    }
    return true;
}
