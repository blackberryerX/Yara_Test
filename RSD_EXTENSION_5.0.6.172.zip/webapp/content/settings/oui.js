_update = function()
{
    if ($("urlUpdate").checked)
    {
        var val = $("updateURL").value;
        OrionCore.showPleaseWait(true);
        OrionCore.doAsyncAction("/rsd/ouiUpdateByURL.do", ["updateURL", val], _success, _error);
    }
    else if ($("fileUpdate").checked)
    {
        var val = $("updateFile").value;
        OrionCore.showPleaseWait(true);
        OrionCore.doAsyncAction("/rsd/ouiUpdateByFile.do", ["updateFile", val], _success, _error);
    }
    else if ($("uploadUpdate").checked)
    {
        OrionForm.setEncoding(OrionForm.MULTIPART);
        OrionCore.doFormAction("/rsd/ouiUpdateByUpload.do", [], "POST");
    }
}

_selectByURL = function()
{
    OrionCore.setEnabledById("updateURL", true);
    OrionCore.setEnabledById("updateFile", false);
    OrionCore.setEnabledById("updateUpload", false);
    OrionCore.setEnabledById("updateUploadButton", _validateByURL());
}

_selectByFile = function()
{
    OrionCore.setEnabledById("updateURL", false);
    OrionCore.setEnabledById("updateFile", true);
    OrionCore.setEnabledById("updateUpload", false);
    OrionCore.setEnabledById("updateUploadButton", _validateByFile());
}

_selectByUpload = function()
{
    OrionCore.setEnabledById("updateURL", false);
    OrionCore.setEnabledById("updateFile", false);
    OrionCore.setEnabledById("updateUpload", true);
    OrionCore.setEnabledById("updateUploadButton", _validateByUpload());
}

_validateByURL = function()
{
    var x = OrionCore.trim($("updateURL").value).length > 0;
    OrionCore.setEnabledById("updateUploadButton", x);

    return x;
}

_validateByFile = function()
{
    var x = OrionCore.trim($("updateFile").value).length > 0;
    OrionCore.setEnabledById("updateUploadButton", x);

    return x;
}

_validateByUpload = function()
{
    var x = OrionCore.trim($("updateUpload").value).length > 0;
    OrionCore.setEnabledById("updateUploadButton", x);
    if($('saveButton'))
    {
        OrionCore.setEnabledById("saveButton", false);
    }
}

_success = function( message )
{
    OrionCore.showPleaseWait(false);
    OrionCore.setDialogBoxTitle($("updateUploadButton").title);
    OrionCore.showMessageBox(true, message, OrionCore.DIALOG_OK);
}

_error = function ( code, message )
{
    OrionCore.showPleaseWait(false);
    OrionCore.setDialogBoxTitle($("updateUploadButton").title);
    OrionCore.showMessageBox(true, message, OrionCore.DIALOG_OK);
}

_ouiStateChanged = function(isDirty, isValid)
{
    if ($("urlUpdate").checked)
    {
        _validateByURL();
    }
    else if ($("fileUpdate").checked)
    {
        _validateByFile();
    }
    else if ($("uploadUpdate").checked)
    {
        _validateByUpload();
    }
}

OrionForm.setStateChangeHandler(_ouiStateChanged);