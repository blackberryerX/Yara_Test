--special case we've changes after 4.7.2 created, this file will be run only during upgrade from 4.7.2
--similar code exist in upgrade 4.7.1-4.7.2
--version 2008 is 10.xxx, since 2008 filtered indexes are supported
IF  EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') 
    AND name = N'IX_RSDDetectedSystemProperties_DomainNetbiosName')
BEGIN
   DROP INDEX [dbo].[RSDDetectedSystemProperties].[IX_RSDDetectedSystemProperties_DomainNetbiosName];
END
GO

    CREATE NONCLUSTERED INDEX [IX_RSDDetectedSystemProperties_DomainNetbiosName] 
           ON [dbo].[RSDDetectedSystemProperties]([Domain],[NetbiosName]);
