
---- revert subnets view
if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSubnets]') and OBJECTPROPERTY(id, N'IsView') = 1)
  drop view [dbo].[RSDSubnets]
GO

CREATE VIEW [dbo].[RSDSubnets]
AS
    SELECT RSDSubnetProperties.SubnetID,
        RSDSubnetProperties.SubnetName,
        RSDSubnetProperties.IPV4,
        RSDSubnetProperties.IPV4mask,
        RSDSubnetProperties.IPV6,
        RSDSubnetProperties.IPV6mask,
        RSDSubnetProperties.Ignored,
        [dbo].[RSDFN_IsSubnetCovered](RSDSubnetProperties.SubnetID, GETUTCDATE()) as Covered,
        RSDSubnetProperties.PrevCoveredState,
        [dbo].[RSDFN_SubnetContainsRogueSystems](RSDSubnetProperties.SubnetID) as ContainsRogue
FROM RSDSubnetProperties
WHERE RSDSubnetProperties.BitBucket = 0
GO

-- revert virtual mac fix
ALTER PROCEDURE [dbo].[RSDSP_MatchDetectedSystems]
(
    @AgentGUID					uniqueidentifier,
    @SourceID					int,
    @SourceType					nvarchar(100),
    @ExternalID					nvarchar(1000),
    @MAC						nvarchar(12),
    @ComputerName				nvarchar(16),
    @Domain						nvarchar(255),
    @DnsName					nvarchar(255),
    @IPV4						int,
    @IPV6						binary (16),
    @DetectionType              nvarchar(255),
    @MatchingOverride	        int,
    @HostID						int output
)
AS
BEGIN
    -- squelch client-side notifications of updates
    set nocount on;

    -- as early as possible
	set @HostID = NULL;

    declare @detectedMatching   int;
    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;
    declare @found              bit;
	declare @done               bit;
	declare @cnt                int;

    -- The Configuration ID by default should always be 1
    if(@MatchingOverride > 0)
		set @detectedMatching = @MatchingOverride
	else
	begin
	    -- include the top row only (which should be sufficient)
		select TOP 1 @detectedMatching = [DetectedMatching]
			from [dbo].[RSDConfiguration]
	end
	
	-- determine feature set being used for matching
    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

	declare @results table (
		HostID				int,
		ComputerName		nvarchar(16),
		Domain				nvarchar(255),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

    -- squelch the domain name if it is an empty string
    if (@Domain = N'')
        set @Domain = NULL;
        
    -- same for computer name
    if (@ComputerName = N'')
        set @ComputerName = NULL;       

    -- slurp the computer name from the full-DNS name if none was provided
    --  AND full-DNS matching is NOT a viable search option.
    if (@ComputerName is null and @DnsName is not null and @DnsName <> N'' and @useDNSName = 0)
    begin
        DECLARE @dot int;
        SET @dot = CHARINDEX(N'.', @DnsName);
        if (@dot > 0)
            set @ComputerName = SUBSTRING(@DnsName, 0, @dot);
        else
            set @ComputerName = @DnsName; -- no dots. use full name
    end
    
	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
        -- only searching for an agent guid, which should unique,
        --  therefore there should be no need to populate a table.
        select top 1 @HostID = HostID
        from RSDDetectedSystemProperties dsp
        where (dsp.AgentGUID = @AgentGUID)
        and (dsp.DetectionType = @DetectionType);

        -- turn out the lights if we have a match.        
        if (@HostID is not null)
        begin
            set @found = 1;
            set @done = 1;
        end
    end

	-- the combination source type + external id also uniquely identify a system
	--  effectively a foreign "guid" managed by the external source
	if (@done = 0 and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
	    -- there can be only one, so make sure of it.
	    select top 1 @HostID = dsp.HostID
        from RSDDetectedSource dsrc inner join RSDDetectedSystemProperties dsp
            on (dsrc.HostID = dsp.HostID and dsrc.SourceType = @SourceType and dsrc.ExternalID = @ExternalID)
        where (dsp.DetectionType = @DetectionType)
        order by dsrc.LastDetectedTime desc;
	    
        -- again, turn out the lights if we have a match.        
        if (@HostID is not null)
        begin
            set @found = 1;
            set @done = 1;
        end
	end
	
	-- Check for a match on the MAC address. Note that this uses *both* the
	--  ePO virtual vendor table and the RSD virtual vendor table, as it is
	--  entirely unclear which is "correct" by any (non-existent) standard.
	if (@done = 0 
	    and @useMAC = 1 
	    and @MAC is not null 
	    and (LEN(@MAC) > 0) 
	  /*  and not exists(
            select * from 
            (   -- sub-select-union for ganging RSD and EPO virtual OUIs
                select OUI from RSDVMVendorOUIs union 
                select VendorID OUI FROM EPOVirtualMacVendor
            ) OUIs
            where substring(@MAC, 0, len(OUIs.OUI)+1) = OUIs.OUI) */
            )
	begin
		-- first check the MAC in the DSP table rather than the interfaces table.
        insert into @results (HostID, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
	        select dsp.[HostID], dsp.[NetbiosName], dsp.[Domain], dsp.[DnsName], dsp.IPV4, dsp.IPV6, dsp.[LastDetectedTime]
	        from [RSDDetectedSystemProperties] dsp
	        where (dsp.MAC = @MAC)
	        and (dsp.DetectionType = @DetectionType)

        -- try the interface properties table next (long shot).
        select @cnt = COUNT(*) from @results;
	    if (@cnt = 0)
	    begin
	        insert into @results (HostID, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
		        select dsp.[HostID], dsp.[NetbiosName], dsp.[Domain], dsp.[DnsName], rip.[IPV4], rip.[IPV6],dsp.[LastDetectedTime]
		        from [RSDDetectedSystemProperties] dsp 
		            inner join [RSDInterfaceProperties] rip 
		            on (dsp.[HostID] = rip.[HostID])
		        where (rip.[MAC] = @MAC)
		        and (dsp.DetectionType = @DetectionType);
		end
		    
        -- retrieve result count. 
        --  * more than zero indicates matches
        --  * exactly one indicates completion (exact match)
        select @cnt = COUNT(*) from @results;
	    if (@cnt > 0)
	    begin
		    set @found = 1;
	        if (@cnt = 1)
	        begin
		        set @done = 1;
		        select top 1 @HostID = HostID from @results;
		    end
	    end
	end

	-- Next, do the ComputerName/Domain pair
	if (@done = 0 and @ComputerName is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin	        
	        -- there can be more than one, so table it.
		    insert into @results (HostID, ComputerName, DnsName, IPV4, IPV6, LastDetectedTime)
			    select dsp.[HostID], dsp.[NetbiosName], dsp.[DnsName], rip.[IPV4], rip.[IPV6],dsp.[LastDetectedTime]
			    from [RSDDetectedSystemProperties] dsp 
			        inner join [RSDInterfaceProperties] rip 
			        on (dsp.[HostID] = rip.[HostID])
                where ((@Domain is not null and dsp.[Domain] = @Domain) or
                     (@Domain is null and dsp.[Domain] is null))
                and (dsp.[NetbiosName] = @ComputerName)
                and (dsp.[DetectionType] = @DetectionType)

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
	        select @cnt = COUNT(*) from @results;
		    if (@cnt > 0)
		    begin
			    set @found = 1;
		        if (@cnt = 1)
		        begin
			        set @done = 1;
			        select top 1 @HostID = HostID from @results;
			    end
		    end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select top 1 @HostID = HostID from @results 
			order by LastDetectedTime desc;

            -- remove anything where the nb-name and domain don't match.
			delete from @results 
			where (ComputerName <> @ComputerName) or (Domain <> @Domain);
			
            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
	        select @cnt = COUNT(*) from @results;
		    if (@cnt > 0)
		    begin
		        if (@cnt = 1)
		        begin
			        set @done = 1;
			        select top 1 @HostID = HostID from @results;
			    end
		    end
		    else
		    begin
		        -- nothing left. just use the host id from before the delete.
		        set @done = 1;
		    end
		end
	end
	
	-- Use DNS name
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
    		insert into @results (HostID, ComputerName, IPV4, IPV6, LastDetectedTime)
			    select dsp.[HostID], dsp.[NetbiosName], rip.[IPV4], rip.[IPV6],dsp.[LastDetectedTime]
			    from [RSDDetectedSystemProperties] dsp
			        inner join [RSDInterfaceProperties] rip
                    on (dsp.[HostID] = rip.[HostID])
			    where (dsp.[DnsName] = @DnsName)
			    and (dsp.DetectionType = @DetectionType);

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
	        select @cnt = COUNT(*) from @results;
		    if (@cnt > 0)
		    begin
			    set @found = 1;
		        if (@cnt = 1)
		        begin
			        set @done = 1;
			        select top 1 @HostID = HostID from @results;
			    end
		    end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select top 1 @HostID = HostID from @results 
			order by LastDetectedTime desc;

            -- throw out any non-match dns names
			delete from @results
			where (DnsName <> @DnsName);

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
            select @cnt = COUNT(*) from @results;
	        if (@cnt > 0)
	        begin
		        set @found = 1;
	            if (@cnt = 1)
	            begin
		            set @done = 1;
		            select top 1 @HostID = HostID from @results;
		        end
	        end
	        else
	        begin
	            -- nothing left. just use the host id from before the delete.
	            set @done = 1;
	        end
		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	-- check on either IPv4 or IPv6 (these really need to be separate)
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null and @IPV4 <> 0)
				begin
                    insert into @results (HostID, ComputerName, LastDetectedTime)
                        select dsp.[HostID],dsp.[NetbiosName],dsp.[LastDetectedTime]
						from [RSDDetectedSystemProperties] dsp 
						    inner join [RSDInterfaceProperties] rip 
						    on (dsp.[HostID] = rip.[HostID])
						where (rip.[IPV4] = @IPV4)
						and (dsp.[DetectionType] = @DetectionType);
				end
				else if (@IPV6 is not null)
				begin
                    insert into @results (HostID, ComputerName, LastDetectedTime)
                        select dsp.[HostID], dsp.[NetbiosName], dsp.[LastDetectedTime]
                        from [RSDDetectedSystemProperties] dsp
						    inner join [RSDInterfaceProperties] rip 
						    on (dsp.[HostID] = rip.[HostID])
						where (rip.[IPV6] = @IPV6)
						and (dsp.[DetectionType] = @DetectionType);
				end

                -- retrieve result count. 
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
	            select @cnt = COUNT(*) from @results;
		        if (@cnt > 0)
		        begin
			        set @found = 1;
		            if (@cnt = 1)
		            begin
			            set @done = 1;
			            select top 1 @HostID = HostID from @results;
			        end
		        end
			end
			else
			begin
                -- need to get the most recent, in case we drop to 0 in our count...
                select top 1 @HostID = HostID from @results 
                order by LastDetectedTime desc;

				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null and @IPV4 <> 0)
				begin
					delete from @results 
					where (IPV4 <> @IPV4);
				end
				else
				begin
					delete from @results 
					where (IPV6 <> @IPV6);
				end

                -- retrieve result count. 
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
	            select @cnt = COUNT(*) from @results;
		        if (@cnt > 0)
		        begin
			        set @found = 1;
		            if (@cnt = 1)
		            begin
			            set @done = 1;
			            select top 1 @HostID = HostID from @results;
			        end
		        end
		        else
		        begin
		            -- nothing left. just use the host id from before the delete.
		            set @done = 1;
		        end
			end
		end
	end

	-- check hostname only (incredibly unreliable, but still an option)
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, LastDetectedTime)
				select dsp.[HostID], dsp.[LastDetectedTime]
				from [RSDDetectedSystemProperties] dsp
				where (dsp.[NetbiosName] = @ComputerName)
				and (dsp.DetectionType = @DetectionType);

            -- determine result count
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
			    set @found = 1;
			    if (@cnt = 1)
			    begin
			        set @done = 1;
				    select top 1 @HostID = HostID from @results;
			    end
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select top 1 @HostID = HostID from @results 
			order by LastDetectedTime desc;

            -- throw out anything that doesn't match just the host name
			delete from @results 
			where (ComputerName <> @ComputerName);

			-- if no data is left, use the prior most recent host
	        select @cnt = COUNT(*) from @results;
		    if (@cnt > 0)
		    begin
			    set @found = 1;
		        if (@cnt = 1)
		        begin
			        set @done = 1;
		            select top 1 @HostID = HostID from @results 
			    end
		    end
		    else
		    begin
		        -- nothing left. just use the host id from before the delete.
		        set @done = 1;
		    end
		end
	end

	-- use the top-most host from our results table if still not done.
	if (@done = 0 and @cnt > 0)
	begin
		select top 1 @HostID = HostID from @results 
		order by LastDetectedTime desc;
	end
END
GO

--------------------------------------------------------------------------------
-- Updates to Managed System matching algorithm.
--------------------------------------------------------------------------------
ALTER PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
    @DetectionType      nvarchar(255)
)
AS
BEGIN
    set nocount on;
    
    declare @managedMatching    int;
    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;
    declare @found              bit;
    declare @cnt                int;
    declare @done               bit;
    declare @m_AgentGUID        uniqueidentifier;
    
    declare @results table 
    (
        AgentGUID       uniqueidentifier,
        ComputerName    nvarchar(255),
        Domain          nvarchar(255),
        DnsName         nvarchar(255),
        IPV4            int,
        IPV6            binary (16)
    );

    -- The Configuration ID by default should always be 1
    select top 1 @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration];

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    set @found = 0;
	set @done = 0;
	set @cnt = 0;
    set @m_AgentGUID = null;

    -- squelch the domain name if it is an empty string
    if (@Domain = N'')
        set @Domain = NULL;
        
    -- same for computer name
    if (@ComputerName = N'')
        set @ComputerName = NULL;       

    -- slurp the computer name from the full-DNS name if none was provided
    --  AND full-DNS matching is NOT a viable search option.
    if (@ComputerName is null and @DnsName is not null and @DnsName <> N'' and @useDNSName = 0)
    begin
        DECLARE @dot int;
        SET @dot = CHARINDEX(N'.', @DnsName);
        if (@dot > 0)
            set @ComputerName = SUBSTRING(@DnsName, 0, @dot);
        else
            set @ComputerName = @DnsName; -- no dots. use full name
    end
    
    -- match on AgentGUID first
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
        select top 1 @m_AgentGUID = AgentGUID 
        from EPOLeafNode ln inner join EPOComputerProperties cp 
            on (ln.AutoID = cp.ParentID)
        where (ln.AgentGUID = @AgentGUID)
        and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
            or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));
        
		-- non-null AgentGUID is unique in EPOLeafNode, so confidence is high.
        if (@m_AgentGUID is not null)
            set @done = 1;
    end

    -- match on MAC address
	if (@done = 0 
	    and @useMAC = 1 
	    and @MAC is not null 
	    and (LEN(@MAC) > 0) 
	    /*and not exists(
            select * from 
            (   -- sub-select-union for ganging RSD and EPO virtual OUIs
                select OUI from RSDVMVendorOUIs union 
                select VendorID OUI FROM EPOVirtualMacVendor
            ) OUIs
            where substring(@MAC, 0, len(OUIs.OUI)+1) = OUIs.OUI) */
            )
	begin
	    -- build list from matching MAC address(es)
		insert into @results (AgentGUID, ComputerName, Domain, DnsName, IPV4, IPV6)
			select ln.[AgentGUID], 
				   cp.[ComputerName],
				   cp.[DomainName],
				   cp.[IPHostName],
				   [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]),
				   cp.[IPV6]
			from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
				on ln.[AutoID] = cp.[ParentID]
			where (cp.[NetAddress] = @MAC)
			and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
               or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

        -- retrieve result count. 
        --  * more than zero indicates matches
        --  * exactly one indicates completion (exact match)
		select @cnt = count(*) from @results;
		if (@cnt > 0)
		begin
			set @found = 1;
		    if (@cnt = 1)
		    begin
			    set @done = 1;
			    select top 1 @m_AgentGUID = AgentGUID from @results;
		    end
		end
	end

    -- match on domain\hostname
	if (@done = 0 and @ComputerName is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (AgentGUID, ComputerName, DnsName, IPV4, IPV6)
				select 
				    ln.[AgentGUID],
				    cp.[ComputerName],
				    cp.[IPHostName],
				    [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]), 
				    cp.[IPV6]
				from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where ((cp.[ComputerName] = @ComputerName) and (cp.[DomainName] = @Domain))
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
				set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select top 1 @m_AgentGUID = AgentGUID from @results;
			    end
			end
		end
		else
		begin
		    -- already have previous results (multiple matches on same mac)
		    --  filter down based on domain\system name
			delete from @results 
			where (ComputerName <> @ComputerName) or (Domain <> @Domain);

            -- unlike RSDSP_MatchDetectedSystems, we don't keep the most-recent
            --  insertion from EPOLeafNode as the match. things must be exact.
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select top 1 @m_AgentGUID = AgentGUID from @results;
			    end
			end
			else
			begin
			    -- not searching any further. no match
			    set @done = 1
			end
		end
	end

    -- match on DNS
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
		    -- look for matches on the DNS name
			insert into @results (AgentGUID, ComputerName, IPV4, IPV6)
				select ln.[AgentGUID],
					   cp.[ComputerName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]),
					   cp.[IPV6]
				from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where (cp.[IPHostName] = @DnsName)
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
				set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select @m_AgentGUID = AgentGUID from @results;
			    end
			end
		end
		else
		begin
		    -- filter out all systems with no matching DNS name
			delete from @results 
			where (DnsName <> @DnsName);

            -- retrieve result count. 
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
			    set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select @m_AgentGUID = AgentGUID from @results;
				end
			end
			else
			begin
			    -- not searching any further. no match
			    set @done = 1;
			end
		end
	end

	-- check on either IPv4 or IPv6 (these really need to be separate)
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
			if (@ipaddr is null or DATALENGTH(@ipaddr) = 0)
			    set @ipaddr = @IPV6
		end
		else
		begin
			set @ipaddr = @IPV6;
		end
		
		-- We only want to do anything if this IPAddress falls in the correct range
		if (@ipaddr is not null and [dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
    			insert into @results (AgentGUID, ComputerName)
					select ln.[AgentGUID],
						   cp.[ComputerName]
				    from [EPOLeafNode] ln
					    inner join [EPOComputerProperties] cp
					    on ln.[AutoID] = cp.[ParentID]
					    where cp.[IPV6] = @ipaddr
                        and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                           or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

                -- retrieve result count. 
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
				select @cnt = count(*) from @results;
				if (@cnt > 0)
				begin
					set @found = 1;
				    if (@cnt = 1)
				    begin
					    set @done = 1;
					    select @m_AgentGUID = AgentGUID from @results;
				    end
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete from @results where (IPV4 <> @IPV4);
				end
				else
				begin
					delete from @results where (IPV6 <> @IPV6);
				end

                -- retrieve result count. 
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
    			select @cnt = count(*) from @results;
				if (@cnt > 0)
				begin
					set @found = 1;
				    if (@cnt = 1)
				    begin
					    set @done = 1;
					    select @m_AgentGUID = AgentGUID from @results;
				    end
				end
				else
				begin
			        -- not searching any further. no match
					set @done = 1;
				end
			end
		end
	end

	-- match on hostname only
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (AgentGUID)
				select ln.[AgentGUID]
				from [EPOLeafNode] ln
					inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where (cp.[ComputerName] = @ComputerName)
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));
		end
		else
		begin
		    -- filter results on hostname from prior selection
			delete from @results 
			where (ComputerName <> @ComputerName);
		end
		
        -- retrieve result count. 
        --  * more than zero indicates matches
        --  * exactly one indicates completion (exact match)
		select @cnt = count(*) from @results;
	    if (@cnt = 1)
	    begin
		    set @done = 1;
		    select @m_AgentGUID = AgentGUID from @results;
	    end
	end

    -- after all of that, we only reduce an update if there is only one
    -- possible match that made it through the above conditionals.
	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID
		and (AgentGUID is null OR AgentGUID <> @m_AgentGUID OR RogueAction is null OR RogueAction <> 0);
	end
END
GO

if exists (select * from sys.views where object_id = object_id(N'.[dbo].[RSDDetectedSystems]'))
  drop view [dbo].[RSDDetectedSystems]
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT
	dsp.HostID,
	dsp.DnsName,
	dsp.OSPlatform,
	dsp.OSFamily,
	dsp.OSVersion,
	dsp.Domain,
	dsp.NetbiosName,
	dsp.NetbiosComment,
	dsp.Users,
	dsp.AgentGUID,
	dsp.FriendlyName,
	dsp.Ignored,
	dsp.Comments,
	dsp.IPV4,
	dsp.IPV6,
	dsp.MAC,
	dsp.Exception,
	dsp.RogueAction,
	dsp.LastDetectedTime,
	dsp.RecordedTime,
	dsp.NewDetection,
	dsp.DeviceType,
	[dbo].[RSDFN_GetLastDetectedSourceId](dsp.HostId) As SourceID,
	o.OUI,
	o.OrgName,
	CASE
		WHEN dsp.AgentGUID IS NULL THEN 0
		WHEN ISNULL(ac.AgentCount, 0) = 0 THEN 1	-- This is an "Alien Agent"
		WHEN n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2	-- This is a "Dead Agent"
		WHEN n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN -1	-- This is a "Managed" machine
		ELSE 0
	END	AS RogueState,
	CAST
	( CASE
		WHEN dsp.Exception = 0
			AND	dsp.AgentGUID IS NOT NULL
			AND	n.LastUpdate IS NOT NULL
			AND	n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
		WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
				) is not null
			) THEN 1
		ELSE 0
	END AS BIT ) AS Managed,
	CAST
	( CASE
        WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
			  ) is not null
			) THEN 0
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime >= DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN	1
		ELSE	0
	END AS BIT ) AS Rogue,
	CAST
	( CASE
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime < DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN 1
		ELSE 0
	END	AS BIT ) AS Inactive,
	dst.SourceName AS DetectedSourceName,
	[dbo].[MAMFN_GetLastReportingSensor](dsp.HostId) As LastReportingSensor,
	n.LastUpdate AS LastAgentCommunication,
	n.AgentVersion AS AgentVersion,
	CASE
		WHEN n.AutoID IS not null THEN (select top 1 ComputerName from [dbo].[EPOServerInfo])
		ELSE (select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID)
	END AS ServerName,
	(select [Name] from [dbo].[RSDExceptionCategories] where CategoryID = dsp.ExceptionCategoryID)
	AS ExceptionCategory
FROM
(
	dbo.RSDDetectedSystemProperties	dsp
	LEFT OUTER JOIN	dbo.EPOLeafNode n ON dsp.AgentGUID = n.AgentGUID
	LEFT OUTER JOIN	dbo.RSDDetectedSourceType dst ON dsp.DetectedSourceType	= dst.SourceType
	LEFT OUTER JOIN	dbo.OUIs o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
	LEFT OUTER JOIN
	(
		SELECT AgentGUID, COUNT(*) AS AgentCount FROM dbo.EPOLeafNode WHERE AgentGUID IS NOT NULL GROUP BY AgentGUID
	) ac ON dsp.AgentGUID = ac.AgentGUID
)
CROSS JOIN
(
	SELECT * FROM dbo.RSDConfiguration WHERE ID = 1
) c
WHERE dsp.Ignored=0;
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_LookupMAMOSInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[RSDSP_LookupMAMOSInfo]
GO

CREATE PROCEDURE [dbo].[RSDSP_LookupMAMOSInfo]
(
    @OSPlatform		   nvarchar(100),
    @OSPlatformOut         nvarchar(25) output,
    @OSFamilyOut           nvarchar(128) output,
    @OSVersionOut          nvarchar(128) output,
    @OSDeviceTypeOut       nvarchar(100) output
)
AS
BEGIN
        -- First set default values
        set @OSPlatformOut = 'Unknown'
        set @OSFamilyOut = null
        set @OSVersionOut = null
        set @OSDeviceTypeOut = 'unknown'

		declare @_OSPlatformTemp        nvarchar(25);
        declare @_OSFamilyTemp          nvarchar(128);
        declare @_OSVersionTemp         nvarchar(128);
        declare @_OSDeviceTypeTemp      nvarchar(100);

        select @_OSPlatformTemp = OsPlatform, @_OSFamilyTemp = Family, @_OSVersionTemp = Version, @_OSDeviceTypeTemp=DeviceType
        from RSDLookupOSName
        where OS_NAME = @OSPlatform

        -- if nothing found revert to Unknown (leave defaults above)
        if (@_OSPlatformTemp is not null and LEN(@_OSPlatformTemp) > 0)
        begin
                set @OSPlatformOut = @_OSPlatformTemp
                if (@_OSFamilyTemp is not null and LEN(@_OSFamilyTemp) > 0)
                begin
                        set @OSFamilyOut = @_OSFamilyTemp
                end
                if (@_OSVersionTemp is not null and LEN(@_OSVersionTemp) > 0)
                begin
                        set @OSVersionOut = @_OSVersionTemp
                end
                if (@_OSDeviceTypeTemp is not null and LEN(@_OSDeviceTypeTemp) > 0)
                begin
                        set @OSDeviceTypeOut = @_OSDeviceTypeTemp
                end
        end
END
GO 
