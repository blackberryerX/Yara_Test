EXEC EPOCore_DropStoredProc N'RSDSP_GetOrionEvents';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddOrionEvent';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddOrUpdateDetectedSourceType';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_DeletedDetectedSourceType';
GO

EXEC EPOCore_DropFunction N'RSDFN_GetLastDetectedSourceId';
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDOrionEvents]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSDOrionEvents]
GO

EXEC EPOCore_DropFunction N'RSDFN_ManagedSystemHasSensor';
GO

CREATE FUNCTION [dbo].[RSDFN_ManagedSystemHasSensor]
(
    @ParentID  int
)
RETURNS bit
AS
BEGIN
    declare @hasSensor int;

	-- This will find out if there is a Sensor installed on this machine
	SELECT @hasSensor = count(*)
	FROM EPOProductProperties
	LEFT JOIN EPOProductFamilies ON EPOProductFamilies.ProductCode=EPOProductProperties.ProductCode
	LEFT JOIN EPOSoftware ON EPOSoftware.ProductCode=EPOProductProperties.ProductCode
	WHERE [EPOProductProperties].[ParentID]= @ParentID and EPOProductProperties.ProductCode = 'SNOWCAP_2000';

	if (@hasSensor <> 0)
		return 1;

	return 0;
END
GO

EXEC EPOCore_DropFunction N'RSDFN_SystemAlreadyHasSensorDeploymentClientTask';
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]') )
DROP FUNCTION [dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]
GO


CREATE FUNCTION [dbo].[RSDFN_SystemAlreadyHasSensorDeploymentClientTask]
(
	@LeafNodeID int
)
RETURNS bit
AS
BEGIN
	-- added in response to bug 414160
	DECLARE @cnt int;

	select @cnt = COUNT(*) from EPOTaskObjects
		left join EPOTaskTypes on EPOTaskObjects.TaskTypeId = EPOTaskTypes.TaskTypeId
		left join EPOTaskAssignments on EPOTaskObjects.TaskObjectId = EPOTaskAssignments.TaskObjectId
		left join EPOTaskObjectSettings on EPOTaskObjects.TaskObjectId = EPOTaskObjectSettings.TaskObjectId
	where EPOTaskTypes.ProductCode = 'SNOWCAP_2000' and EPOTaskTypes.TaskType = 'SensorDeployment' and
		EPOTaskAssignments.NodeId = @LeafNodeID and
		EPOTaskObjectSettings.SectionName = 'Install' and
		EPOTaskObjectSettings.SettingName = 'NumInstalls' and
		EPOTaskObjectSettings.SettingValue = '1'

    if (@cnt = 1)
        return 1;

	return 0;
END
GO

EXEC [EPOCore_DropStoredProc] N'EPORSD_MigratePoliciesToMeta';
GO

----------------------------------------------------------------
--  BEGIN Migration
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSD47MigrateTaskObjectSettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSD47MigrateTaskObjectSettings]
GO

EXEC [EPOCore_DropStoredProc] N'EPORSD_SaveTaskSettingsFor47Migration';
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSD47MigrateTaskAssignments]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RSD47MigrateTaskAssignments]
GO

EXEC [EPOCore_DropStoredProc] N'EPORSD_Add47MigratedTaskAssignment';
GO

----------------------------------------------------------------
--  END Migration
----------------------------------------------------------------


----------------------------------------------------------------
--  BEGIN Canonical Name / Matching Override API
----------------------------------------------------------------
EXEC EPOCore_DropStoredProc N'RSDSP_UpdateDetectedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystems]
(
    @DnsName            nvarchar(255),
    @OSPlatform         nvarchar(25),
    @OSFamily           nvarchar(128),
    @OSVersion          nvarchar(128),
    @Domain             nvarchar(255),
    @NetbiosName        nvarchar(16),
    @NetbiosComment     nvarchar(100),
    @Users              nvarchar(128),
    @AgentGUID          uniqueidentifier,
    @IPV4               int,
    @IPV6               varbinary (16),
    @MAC                nvarchar(12),
    @DetectedTime       datetime,
    @DeviceType         nvarchar(100),
    @SourceID           int,
    @SourceType         nvarchar(100),
    @ExternalID         nvarchar(1000),
    @OutputHostID		int OUTPUT,
    @OutputNewDetection bit OUTPUT
)
AS
BEGIN
    declare @NewDetection bit;
    set @NewDetection = 0;

    declare @FriendlyName nvarchar(255);
    declare @HostID int;

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);

		-- bug 431315 - if MAC is from a VPN or other "exclude this" list, then don't use it (set to null)
		declare @OUI nvarchar(6);
		set @OUI = SUBSTRING(@MAC, 0, 7);

		declare @vendorIdCount int;
		select @vendorIdCount = count(*) from EPOVirtualMacVendor where VendorID = @OUI;
		if (@vendorIdCount > 0)
		begin
			set @MAC = NULL;
		end
    end;

    if (DATALENGTH(@IPV6) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @IPV6;
    end

    -- Begin fix for 457424 / 457673
	-- If the interface is in an ignored subnet, do not add the interface
	-- and make sure we don't end up orphaning a detected system object
    declare @OutSubnetID int;
    if (@IPV6 is not null)
    begin
        exec RSDSP_FindSubnetForIPAddress @IPV6, @OutSubnetID output
    end

	-- If the subnetid is not null and the associated subnet is "ignored", then we don't want to continue
	if (@OutSubnetID is not null and exists(select 1 from RSDSubnetProperties where SubnetID = @OutSubnetID and Ignored = 1))
	begin
		-- We're going to bail out of here now
		set @OutputHostID = 0;
		set @OutputNewDetection = 0;
		return;
	end
	-- End fix for 457424 / 457673

	-- Match detected systems
	exec RSDSP_MatchDetectedSystems @AgentGUID, @SourceID, @SourceType, @ExternalID,
		@MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @HostID output;

    -- Keep track of when this item was recorded
    declare @RecordedTime datetime;
    set @RecordedTime = GETUTCDATE();

    -- If this identity algoritm returns a match, then update the DetectedSystem,
    -- Interfaces, DetectedSource, and Status with the new data
    if (@HostID is not null)
    begin
        -- We need to get the existing data and replace all non-null values with updated data
        declare @_DnsName            nvarchar(255);
        declare @_OSPlatform         nvarchar(25);
        declare @_OSFamily           nvarchar(128);
        declare @_OSVersion          nvarchar(128);
        declare @_Domain             nvarchar(255);
        declare @_NetbiosName        nvarchar(16);
        declare @_NetbiosComment     nvarchar(100);
        declare @_Users              nvarchar(128);
        declare @_AgentGUID          uniqueidentifier;
        declare @_IPV4               int;
        declare @_IPV6               varbinary (16);
        declare @_MAC                nvarchar(12);
        declare @_DetectedTime       datetime;
        declare @_DeviceType         nvarchar(100);
        declare @_SourceType         nvarchar(100);

        select TOP 1 @_DnsName = DnsName,
               @_OSPlatform = OSPlatform,
               @_OSFamily = OSFamily,
               @_OSVersion = OSVersion,
               @_Domain = [Domain],
               @_NetbiosName = NetbiosName,
               @_NetbiosComment = NetbiosComment,
               @_Users = Users,
               @_AgentGUID = AgentGUID,
               @_IPV4 = IPV4,
               @_IPV6 = IPV6,
               @_MAC = MAC,
               @_DetectedTime = LastDetectedTime,
               @_DeviceType = DeviceType,
               @_SourceType = DetectedSourceType
        from [dbo].[RSDDetectedSystemProperties]
        where HostID = @HostID;

		if (@DnsName is null or LEN(@DnsName) = 0)
			set @DnsName = @_DnsName;

		if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
		    set @OSPlatform = @_OSPlatform;

		if (@OSFamily is null or LEN(@OSFamily) = 0)
			set @OSFamily = @_OSFamily;

		if (@OSVersion is null or LEN(@OSVersion) = 0)
			set @OSVersion = @_OSVersion;

		if (@Domain is null or LEN(@Domain) = 0)
			set @Domain = @_Domain;

		if (@NetbiosName is null or LEN(@NetbiosName) = 0)
			set @NetbiosName = @_NetbiosName;

		if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
			set @NetbiosComment = @_NetbiosComment;

		if (@Users is null or LEN(@Users) = 0)
			set @Users = @_Users;

        set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);

		if (@MAC is null or LEN(@MAC) = 0)
			set @MAC = @_MAC;

        set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

		if (@DeviceType is null or LEN(@DeviceType) = 0)
			set @DeviceType = @_DeviceType;

        set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);

        update [dbo].[RSDDetectedSystemProperties]
        set DnsName = @DnsName,
            OSPlatform = @OSPlatform,
            OSFamily = @OSFamily,
            OSVersion = @OSVersion,
            [Domain] = @Domain,
            NetbiosName = @NetbiosName,
            NetbiosComment = @NetbiosComment,
            Users = @Users,
            AgentGUID = @AgentGUID,
            IPV4 = @IPV4,
            IPV6 = @IPV6,
            MAC = @MAC,
            LastDetectedTime = @DetectedTime,
            FriendlyName = @FriendlyName,
            DetectedSourceType = @SourceType,
            RecordedTime = @RecordedTime,
            DeviceType = @DeviceType,
            NewDetection = 0
        where HostID = @HostID;
    end
    else
    begin
        -- Friendly name is determined by the following, whichever one is not null
		set nocount on;
        set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);

        -- Otherwise, add a new row to the DetectedSystems, Interfaces, Status,
        -- DetectedSource and if the RDSSubnets doesn't have associated subnets
        -- we'll need to add in subnet tables, too...
        insert into [dbo].[RSDDetectedSystemProperties] (DnsName, OSPlatform, OSFamily, OSVersion, [Domain],
            NetbiosName, NetbiosComment, Users, AgentGUID, FriendlyName, IPV4, IPV6, MAC,
            LastDetectedTime, DetectedSourceType, Ignored, RecordedTime, DeviceType, NewDetection)
        values (@DnsName, @OSPlatform, @OSFamily, @OSVersion, @Domain,
            @NetbiosName, @NetbiosComment, @Users, @AgentGUID, @FriendlyName, @IPV4, @IPV6, @MAC,
            @DetectedTime, @SourceType, 0, @RecordedTime, @DeviceType, 1);
        select @HostID = SCOPE_IDENTITY();

        set @NewDetection = 1;
    end

	-- Updates the Detected System with the matching ManagedSystem, if it exists...
	 exec RSDSP_MatchManagedSystems @HostID, @AgentGUID, @MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6

	-- if the external id is provided, use it as further qualification when performing
	--  the detected source update. otherwise use the base info.
	if (@HostID IS NOT NULL)
	begin
		declare @dsid int;
		if (@ExternalID is not null)
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType)
				and (ExternalID = @ExternalID);
		end
		else
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType);
		end

		-- update source record timestamps
		if (@dsid is not null)
		begin
			update RSDDetectedSource
				set LastDetectedTime = @DetectedTime, LastRecordedTime = @RecordedTime
				where AutoID = @dsid;
		end
		else
		begin
			-- add  detected source record, which couldn't have existed prior because there was no hostid.
			insert into RSDDetectedSource (HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			values (@HostID, @SourceID, @SourceType, @ExternalID, @DetectedTime, @DetectedTime, @RecordedTime, @RecordedTime);
		end
	end

    -- Gonna need a second stored procedure for the interfaces and subnets, so return the HostID for the
    -- next round of inserts
	set @OutputHostID = @HostID;
    set @OutputNewDetection = @NewDetection;
END
GO



-- This tries to select and match the incoming detected system with existing managed machines
EXEC EPOCore_DropStoredProc N'RSDSP_MatchDetectedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchDetectedSystems]
(
    @AgentGUID          uniqueidentifier,
	@SourceID			int,
	@SourceType			nvarchar(100),
	@ExternalID			nvarchar(1000),
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
	@HostID				int output
)
AS
BEGIN
    declare @detectedMatching    int;

    -- The Configuration ID by default should always be 1
    select @detectedMatching = [RSDConfiguration].[DetectedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @detectedMatching & 0x1;
    set @useProductGUID = @detectedMatching & 0x2;
    set @useMAC = @detectedMatching & 0x10;
    set @useHostnameDomain = @detectedMatching & 0x20;
    set @useDNSName = @detectedMatching & 0x40;
    set @useIPAddress = @detectedMatching & 0x80;
    set @useHostname = @detectedMatching & 0x100;

    declare @found bit;
	declare @done bit;
	declare @cnt int;
	declare @results table (
		HostID				int,
		AgentGUID		    uniqueidentifier,
		SourceID			int,
		SourceType			nvarchar(100),
		ExternalID			nvarchar(1000),
		MAC					nvarchar(12),
		ComputerName		nvarchar(16),
		Domain				nvarchar(255),
		DnsName				nvarchar(255),
		IPV4				int,
		IPV6				binary (16),
		LastDetectedTime	datetime
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

	-- Check for a match on the agent guid
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSystemProperties].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			select @HostID = HostID from @results;
			set @done = 1;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
    end

	-- Like AgentGUID - this should uniquely identify a single system, if not, then we fall through to the user
	-- defined selections
	if (@done = 0 and @SourceType is not null and @ExternalID is not null and @useProductGUID = 1)
	begin
		insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
			select [RSDDetectedSystemProperties].[HostID],
				   [RSDDetectedSystemProperties].[AgentGUID],
				   [RSDDetectedSource].[SourceID],
				   [RSDDetectedSource].[SourceType],
				   [RSDDetectedSource].[ExternalID],
				   [RSDInterfaceProperties].[MAC],
				   [RSDDetectedSystemProperties].[NetbiosName],
				   [RSDDetectedSystemProperties].[Domain],
				   [RSDDetectedSystemProperties].[DnsName],
				   [RSDInterfaceProperties].[IPV4],
				   [RSDInterfaceProperties].[IPV6],
				   [RSDDetectedSystemProperties].[LastDetectedTime]
			from [RSDDetectedSystemProperties] WITH (NOLOCK)
				 inner join [RSDInterfaceProperties] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
				 inner join [RSDDetectedSource] WITH (NOLOCK)
					on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
			where [RSDDetectedSource].[SourceType] = @SourceType
				and [RSDDetectedSource].[ExternalID] = @ExternalID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
			set @done = 1;
			select @HostID = HostID from @results;
		end
		if (@cnt > 1)
		begin
			set @found = 1;
		end
	end


	-- Check for a match on the MAC address...
	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDInterfaceProperties].[MAC] = @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where MAC <> @MAC;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Next, do the ComputerName/Domain pair
	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName
					and [RSDDetectedSystemProperties].[Domain] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName and Domain <> @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- Use DNS name
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[DnsName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R where DnsName <> @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV4] = @IPV4;
				end
				else
				begin
                    insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
                        select [RSDDetectedSystemProperties].[HostID],
                               [RSDDetectedSystemProperties].[AgentGUID],
                               [RSDDetectedSource].[SourceID],
                               [RSDDetectedSource].[SourceType],
                               [RSDDetectedSource].[ExternalID],
                               [RSDInterfaceProperties].[MAC],
                               [RSDDetectedSystemProperties].[NetbiosName],
                               [RSDDetectedSystemProperties].[Domain],
                               [RSDDetectedSystemProperties].[DnsName],
                               [RSDInterfaceProperties].[IPV4],
                               [RSDInterfaceProperties].[IPV6],
                               [RSDDetectedSystemProperties].[LastDetectedTime]
						from [RSDDetectedSystemProperties] WITH (NOLOCK)
							 inner join [RSDInterfaceProperties] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
							 inner join [RSDDetectedSource] WITH (NOLOCK)
								on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
						where [RSDInterfaceProperties].[IPV6] = @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end
			end
			else
			begin
                -- need to get the most recent, in case we drop to 0 in our count...
                select @HostID = HostID from @results order by LastDetectedTime desc;

				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

                select @cnt = count(*) from @results;
                if (@cnt = 0)
                begin
                    -- use the host that was most recently detected
                    set @done = 1;
                end
                if (@cnt = 1)
                begin
                    set @done = 1;
                    select @HostID = HostID from @results;
                end
                if (@cnt > 1)
                begin
                    set @found = 1;
                end

			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (HostID, AgentGUID, SourceID, SourceType, ExternalID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6, LastDetectedTime)
				select [RSDDetectedSystemProperties].[HostID],
					   [RSDDetectedSystemProperties].[AgentGUID],
					   [RSDDetectedSource].[SourceID],
					   [RSDDetectedSource].[SourceType],
					   [RSDDetectedSource].[ExternalID],
					   [RSDInterfaceProperties].[MAC],
					   [RSDDetectedSystemProperties].[NetbiosName],
					   [RSDDetectedSystemProperties].[Domain],
					   [RSDDetectedSystemProperties].[DnsName],
					   [RSDInterfaceProperties].[IPV4],
					   [RSDInterfaceProperties].[IPV6],
					   [RSDDetectedSystemProperties].[LastDetectedTime]
				from [RSDDetectedSystemProperties] WITH (NOLOCK)
					 inner join [RSDInterfaceProperties] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDInterfaceProperties].[HostID]
					 inner join [RSDDetectedSource] WITH (NOLOCK)
						on [RSDDetectedSystemProperties].[HostID] = [RSDDetectedSource].[HostID]
				where [RSDDetectedSystemProperties].[NetbiosName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			-- need to get the most recent, in case we drop to 0 in our count...
			select @HostID = HostID from @results order by LastDetectedTime desc;

			delete R from @results as R  where ComputerName <> @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 0)
			begin
				-- use the host that was most recently detected
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @HostID = HostID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end

		end
	end

	-- If we never were able to narrow it down to just one, return the most recently detected host from our temp table
	if (@done = 0 and @cnt > 1)
	begin
		select @HostID = HostID from @results order by LastDetectedTime desc;
	end
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_CreateAgentUpdateDetection]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_CreateAgentUpdateDetection]
GO

CREATE PROCEDURE [dbo].[RSDSP_CreateAgentUpdateDetection]
(
    @LeafNodeID   int,
    @AgentGUID    uniqueidentifier,
	@DnsName			nvarchar(255),
	@OSPlatformStr		nvarchar(100),
	@OSVersion          nvarchar(128),
	@Domain             nvarchar(255),
	@ComputerName       nvarchar(255),
	@Users              nvarchar(128),
	@IPV6               binary(16),
	@IPV6mask           binary(16),
	@IPV6subnet         binary(16),
	@MACStr             nvarchar(100)
)
AS
BEGIN

	declare @NetbiosName		nvarchar(16);
	declare @OSPlatform         nvarchar(25);
	declare @MAC                nvarchar(12);
	declare @DetectedTime       datetime;
	declare @SourceType         nvarchar(100);
    declare @DeviceType         nvarchar(100);

	declare @OutputHostID		int;
	declare @OutputNewDetection bit;

    if (@IPV6 is null)
    begin
        return;
    end

	set @NetbiosName = SUBSTRING(@ComputerName,1,16);

    if (@MACStr is not null)
    begin
        -- Handle solaris agent problem (bug 449222)
        set @MAC = [dbo].[RSDFN_ValidateMACString](@MACStr);
    end

	if (@OSPlatformStr like '%Windows%')
	begin
		set @OSPlatform = 'Windows'
	end
	else if (@OSPlatformStr like '%Mac%' or @OSPlatformStr like '%Apple%')
	begin
		set @OSPlatform = 'Macintosh'
	end
	else if (@OSPlatformStr like '%Linux%')
	begin
		set @OSPlatform = 'Linux'
	end
	else if (@OSPlatformStr like '%BSD%')
	begin
		set @OSPlatform = 'BSD'
	end
	else if (@OSPlatformStr like '%IRIX%')
	begin
		set @OSPlatform = 'IRIX'
	end
	else if (@OSPlatformStr like '%HP-UX%')
	begin
		set @OSPlatform = 'HP-UX'
	end
	else if (@OSPlatformStr like '%AIX%')
	begin
		set @OSPlatform = 'AIX'
	end
	else if (@OSPlatformStr like '%Netware%' or @OSPlatformStr like '%Novell%')
	begin
		set @OSPlatform = 'Novell'
	end
	else if (@OSPlatformStr like '%Sun%' or @OSPlatformStr like '%Solaris%')
	begin
		set @OSPlatform = 'Sun'
	end
	else if (@OSPlatformStr like '%Unix%')
	begin
		set @OSPlatform = 'Unix'
	end
	else
	begin
		set @OSPlatform = 'Unknown'
	end

	if (@OSPlatform <> 'Windows')
	begin
		set @NetbiosName = null;
		set @Domain = null;
	end


    if (@OSPlatform = 'Unknown')
    begin
        set @DeviceType = 'unknown';
    end
    else
    begin
        set @DeviceType = 'computer';
    end


	set @DetectedTime = GETUTCDATE();

	set @SourceType = 'epo.agent';

	exec [dbo].[RSDSP_UpdateDetectedSystems] @DnsName, @OSPlatform, null, @OSVersion, @Domain, @NetbiosName,
		null, @Users, @AgentGUID, null, @IPV6, @MAC, @DetectedTime, @DeviceType, @LeafNodeID, @SourceType, null,
		@OutputHostID output, @OutputNewDetection output;

	exec [dbo].[RSDSP_UpdateInterfaces] @OutputHostID, @MAC, null, null, null, @IPV6, @IPV6mask, @IPV6subnet,
		@DetectedTime, @LeafNodeID, @SourceType, null;

END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
GO



-- PROCEDURE [RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
--
-- This will add the data from a Detected System to the ePO System Tree
--
-- INPUT	@HostID - The HostID of the detected system to add to the ePO System Tree
--          @BranchNodeID - The place in the tree to add this, if null, add to global root
--          @AllowDuplicates - If false, search the entire DB for existing leaf node entry
--          @DirSort - If true, will tell ePO to sort the computer immediately after
-- OUTPUT	@ResultCode contains the result code of the operation
--   0 - Success
--   1 - No detected system exists for HostID
--   2 - AgentGUID exists, not usable as this system is already "managed"
--   3 - Unable to add host, IP address already exists in system tree
--   4 - Duplicate node already exists in the tree
-- OUTPUT	@ResultMessage contains a string that can be used for logging - it is not localized; localized version should
--   come from translating the @ResultCode value in the UI if necessary
CREATE PROCEDURE [dbo].[RSDSP_AddDetectedSystemToEPOSystemTreeAndSort]
(
    @HostID             int,
    @BranchNodeID       int,
    @AllowDuplicates    bit,
    @DirSort            bit,
    @ResultHostName     nvarchar(255) OUTPUT,
    @ResultCode         int OUTPUT,
    @ResultMessage      nvarchar(1000) OUTPUT
)
AS
BEGIN

    set nocount on;

    -- Find the detected system, gather up all the available properties
    declare @DnsName            nvarchar(255)
    declare @OSPlatform         nvarchar(25)
    declare @OSFamily           nvarchar(128)
    declare @OSVersion          nvarchar(128)
    declare @Domain             nvarchar(255)
    declare @NetbiosName        nvarchar(16)
    declare @NetbiosComment     nvarchar(100)
    declare @Users              nvarchar(128)
    declare @AgentGUID          uniqueidentifier
    declare @IPV6               binary (16)
    declare @MAC                nvarchar(12)
    declare @FriendlyName       nvarchar(255)

    -- TODO: What happens when there are multiple interfaces???  EPO only cares about a single MAC/IP, where
    -- the detected systems has a many to one relationship...  What if the "last detected" MAC/IP is different
    -- than the one expected???  May not be much of an issue for Foundstone with this first cut, but WILL be more
    -- important as the API evolves...  Need to handle this issue via documentation AT A MINIMUM for this release...
    select @DnsName = DnsName,
        @OSPlatform = OSPlatform,
        @OSFamily = OSFamily,
        @OSVersion = OSVersion,
        @Domain = Domain,
        @NetbiosName = NetbiosName,
        @NetbiosComment = NetbiosComment,
        @Users = Users,
        @AgentGUID = AgentGUID,
        @FriendlyName = FriendlyName,
        @IPV6 = IPV6,
        @MAC = MAC
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @HostID;

    -- If the NetbiosName is null, we should use the IP address as the name
    if (@NetbiosName is null and @IPV6 is not null)
    begin
        set @NetbiosName = [dbo].[RSDFN_ConvertIPAddrToDisplayString](@IPV6);
    end
    if (@NetbiosName is null and @MAC is not null)
    begin
        set @NetbiosName = @MAC;
    end

    set @ResultHostName = @FriendlyName;

    -- TODO: If an AgentGUID is found, should we "exit"???  These, technically, should not ever be "managed" machines...
    if (@AgentGUID is not null)
    begin
        set @ResultCode = 2;
        set @ResultMessage = N'AgentGUID already exists for ' + @FriendlyName + ' (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
    end

    -- If the user passed in a branch node, use that one, otherwise use the global lost and found
    if (@BranchNodeID is null)
    begin
        -- Find the global Lost&Found group, which is where this data will go initially
        -- retrieve default home, which is the global Lost&Found group
        DECLARE @DirectoryID int
        SELECT @DirectoryID = AutoID
            FROM [dbo].[EPOBranchNode]
            WHERE ([Type] = 4);

        -- global lost and found is the only type(5) child of directory
        SELECT @BranchNodeID = AutoID
            FROM [dbo].[EPOBranchNode]
            WHERE ([ParentID] = @DirectoryID)
            AND ([Type] = 5);
    end

    declare @dupcnt int;
    if (@AllowDuplicates = 0)
    begin
		-- If we don't allow duplicates, then we search the entire tree
        select @dupcnt = count(*) from EPOLeafNode where NodeName = @NetbiosName;
	end
	else
	begin
		-- If we do allow duplicates, then we search just make sure we don't allow them in the same branch
		select @dupcnt = COUNT(*) from EPOLeafNode where NodeName = @NetbiosName and ParentID = @BranchNodeID;
    end

    if (@dupcnt > 0)
    begin
        set @ResultCode = 4;
        set @ResultMessage = N'Node already exists named ' + @NetbiosName + ' (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
        return;
    end

    declare @iMAC           nvarchar(12)
    declare @iIPV6          binary(16)

    declare @SubnetID       int
    declare @Subnet         int
    declare @SubnetMask     int

    select @iMAC = MAC,
        @iIPV6 = IPV6,
        @SubnetID = SubnetID
    from [dbo].[RSDInterfaceProperties]
    where HostID = @HostID;

    -- If there are properties found, use these one over the ones found in the RSDDetectedSystemProperties table
    if (@iMAC is not null) set @MAC = @iMAC;
    if (@iIPV6 is not null) set @IPV6 = @iIPV6;

    select @Subnet = IPV6,
        @SubnetMask = IPV6mask
    from [dbo].[RSDSubnetProperties]
    where SubnetID = @SubnetID;

	-- IPV6 must be something, otherwise this can't be added to ePO...
	if (@IPV6 is null or @IPV6 = 0x00000000000000000000FFFFFFFFFFFF)
	begin
		set @ResultCode = 1;
		set @ResultMessage = N'No IP address exists, cannot add '+@FriendlyName+' to System Tree (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
	end

	-- Also check the IP address if we have a "don't allow duplicates" set...
    if (@AllowDuplicates = 0)
    begin
		-- If we don't allow duplicates, then we search the entire tree
		select @dupcnt = count(*) from [dbo].[EPOComputerProperties] where IPV6 = @IPV6 or ComputerName = @NetbiosName;
	end
	else
	begin
		-- If we do allow duplicates, then we search just make sure we don't allow them in the same branch
		select @dupcnt = count(*) from [dbo].[EPOComputerProperties]
			left join [dbo].[EPOLeafNode] on [dbo].[EPOComputerProperties].ParentID = [dbo].[EPOLeafNode].AutoID
			where (EPOComputerProperties.IPV6 = @IPV6 or EPOComputerProperties.ComputerName = @NetbiosName) and (EPOLeafNode.ParentID = @BranchNodeID);
    end

	if (@dupcnt > 0)
	begin
		set @ResultCode = 3;
		set @ResultMessage = N'IP address already exists, cannot add '+@FriendlyName+' to System Tree (HostID '+CONVERT(NVARCHAR(10), @HostID)+')';
		return;
	end

    -- Create an EPOLeafNode record (which also magically creates me an EPOComputerProperties record)
    declare @LeafNodeID int;
    insert into [dbo].[EPOLeafNode] (NodeName, Type, ParentID, ResortEnabled, ResortedOnce)
    values (@NetbiosName, 1, @BranchNodeID, 1, 0)

    select @LeafNodeID = SCOPE_IDENTITY();

    -- Update all the EPOComputerProperties columns from the detected system object now
    -- The IP Address also triggers the IPV4x, IPV4 and IPV6 columns to be set with values...
    update [dbo].[EPOComputerProperties]
    set DomainName = @Domain,
        IPAddress = [dbo].[RSDFN_ConvertIntToIPString]([dbo].[RSDFN_ConvertIPV6BinaryToInt](@IPV6)),
        IPV6 = @IPV6,
        OSType = @OSFamily,
        OSVersion = @OSVersion,
        OSPlatform = @OSPlatform,
        Description = @NetbiosComment,
        UserName = @Users,
        IPHostName = @DnsName,
        NetAddress = @MAC
    where ParentID = @LeafNodeID;

    -- Should we tag and sort this node or not?
    if (@DirSort = 1)
    begin
        exec [dbo].[EPOTags_AutoTagComputerASCI] @LeafNodeID;
        exec [dbo].[EPODirSort_ResortSingleComputerASCI] @LeafNodeID, DEFAULT, DEFAULT, DEFAULT;
    end

    -- Now, delete any existing links for this HostID in the link table, we'll create a new one...
    delete from [dbo].[RSDUnmanagedSystemsLink] where DetectedSystemHostID = @HostID;
    insert into [dbo].[RSDUnmanagedSystemsLink]  (DetectedSystemHostID, EPOLeafNodeID) values (@HostID, @LeafNodeID);

    -- All done, eh...
    set @ResultCode = 0;
    set @ResultMessage = 'Success';

END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]
GO

CREATE PROCEDURE [dbo].[RSDSP_DetectedSystemTransaction_DetectedSystemByHostID]
(
    @HostID int
)
AS
BEGIN
    SET NOCOUNT ON;

    select RSDDetectedSystemProperties.AgentGUID,
        RSDDetectedSystemProperties.LastDetectedTime,
        RSDDetectedSystemProperties.DnsName,
        RSDDetectedSystemProperties.Domain,
        RSDDetectedSystemProperties.NetbiosComment,
        RSDDetectedSystemProperties.NetbiosName,
        RSDDetectedSystemProperties.OSFamily,
        RSDDetectedSystemProperties.OSPlatform,
        RSDDetectedSystemProperties.OSVersion,
        RSDDetectedSystemProperties.Users,
        RSDDetectedSystemProperties.FriendlyName
    from [dbo].[RSDDetectedSystemProperties] where HostID = @HostID;

END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]
GO


CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystemPropertiesByHostID]
(
	@HostID				int,
    @DnsName            nvarchar(255),
    @OSPlatform         nvarchar(25),
    @OSFamily           nvarchar(128),
    @OSVersion          nvarchar(128),
    @Domain             nvarchar(255),
    @NetbiosName        nvarchar(16),
    @NetbiosComment     nvarchar(100),
    @Users              nvarchar(128)
)
AS
BEGIN
	if (@HostID is null or @HostID = 0)
	begin
		-- Not set, can't do anything useful...
		return;
	end

    -- We need to get the existing data and replace all non-null values with updated data
    declare @_DnsName            nvarchar(255);
    declare @_OSPlatform         nvarchar(25);
    declare @_OSFamily           nvarchar(128);
    declare @_OSVersion          nvarchar(128);
    declare @_Domain             nvarchar(255);
    declare @_NetbiosName        nvarchar(16);
    declare @_NetbiosComment     nvarchar(100);
    declare @_Users              nvarchar(128);

    select @_DnsName = DnsName,
           @_OSPlatform = OSPlatform,
           @_OSFamily = OSFamily,
           @_OSVersion = OSVersion,
           @_Domain = [Domain],
           @_NetbiosName = NetbiosName,
           @_NetbiosComment = NetbiosComment,
           @_Users = Users
    from [dbo].[RSDDetectedSystemProperties]
    where HostID = @HostID;

	if (@DnsName is null or LEN(@DnsName) = 0)
		set @DnsName = @_DnsName;

	if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
	    set @OSPlatform = @_OSPlatform;

	if (@OSFamily is null or LEN(@OSFamily) = 0)
		set @OSFamily = @_OSFamily;

	if (@OSVersion is null or LEN(@OSVersion) = 0)
		set @OSVersion = @_OSVersion;

	if (@Domain is null or LEN(@Domain) = 0)
		set @Domain = @_Domain;

	if (@NetbiosName is null or LEN(@NetbiosName) = 0)
		set @NetbiosName = @_NetbiosName;

	if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
		set @NetbiosComment = @_NetbiosComment;

	if (@Users is null or LEN(@Users) = 0)
		set @Users = @_Users;

    update [dbo].[RSDDetectedSystemProperties]
    set DnsName = @DnsName,
        OSPlatform = @OSPlatform,
        OSFamily = @OSFamily,
        OSVersion = @OSVersion,
        [Domain] = @Domain,
        NetbiosName = @NetbiosName,
        NetbiosComment = @NetbiosComment,
        Users = @Users
    where HostID = @HostID;

END
GO

----------------------------------------------------------------
--  END Matching Override change
----------------------------------------------------------------

----------------------------------------------------------------
--  START BUG 699813 - Detected systems, Top entry shows root
--  IPV6 subnet 00000000000000000 discovered.
----------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddOrUpdateSubnets]') AND xtype = 'P')
drop procedure [dbo].[RSDSP_AddOrUpdateSubnets]
GO

CREATE PROCEDURE [dbo].[RSDSP_AddOrUpdateSubnets]
(
    @SubnetAddress varbinary(16),
    @SubnetMask varbinary(16)
)
AS
BEGIN
    if (@SubnetAddress is null or DATALENGTH(@SubnetAddress) = 0 or @SubnetMask is null or DATALENGTH(@SubnetMask) = 0)
        return;

    declare @IPV6 binary(16);
    declare @IPV6mask binary(16);

    if (DATALENGTH(@SubnetAddress) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @SubnetAddress;
    end
    else
    begin
        set @IPV6 = @SubnetAddress;
    end

    if (DATALENGTH(@SubnetMask) = 4)
    begin
        set @IPV6mask = 0x00000000000000000000FFFF + @SubnetMask;
    end
    else
    begin
        set @IPV6mask = @SubnetMask;
    end

	-- Reject bad subnet masks that would cover extremely wide address range
	if ([dbo].[RSDFN_IsValidIPV6AddressAndMask](@IPV6, @IPV6mask) = 0)
		return;

    declare @snid int;
    set @snid = [dbo].[RSDFN_GetSubnetID](@IPV6, @IPV6mask);
    -- If this subnet does not exist, then we need to add it...
    if (@snid is null)
    begin
        exec [dbo].[RSDSP_UpdateSubnets] @IPV6, @IPV6mask, @snid output;
    end
END
GO

-- =============================================
-- Function:    [RSDFN_IsValidIPV6AddressAndMask]
-- Description: This function validates IPV6 address and mask so that
--              they are not all zero or the mask is consecutive 1s
--              in binary.
-- Parameter:   @IPV6 - IPV4 or IPV6 address
--              @IPV6Mask - IPV4 or IPV6 net mask. Currently
--              only IPv4 or IPv6-compatible IPV4 addresses
--              are checked. It returns 1 for true IPV6 masks.
-- Returns:     A BIT. 1 is valid, 0 is invalid.
-- =============================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsValidIPV6AddressAndMask]') AND xtype = 'FN')
	DROP FUNCTION [dbo].[RSDFN_IsValidIPV6AddressAndMask]
GO
CREATE FUNCTION [dbo].[RSDFN_IsValidIPV6AddressAndMask](@IPV6 varbinary(16), @IPV6Mask varbinary(16))
RETURNS BIT
AS
BEGIN
	-- Reject zero subnet addresses or mask
	if (@IPV6 =     0x00000000000000000000000000000000 OR
		@IPV6mask = 0x00000000000000000000000000000000 OR
		@IPV6 =     0x00000000000000000000FFFF00000000 OR
		@IPV6mask = 0x00000000000000000000FFFF00000000)
	BEGIN
		return 0;
	END

	-- removing fix for bug 731092.  This introduces a data loss bug (bug 772534)
    -- Hope to fix in next patch.
    -- Don't mix IPv4 address and IPv6 mask
    --if ((SUBSTRING(@IPV6, 1, 12) = 0x00000000000000000000FFFF) AND
    --    (NOT (SUBSTRING(@IPV6mask, 1, 12) = 0x00000000000000000000FFFF)))
    --BEGIN
    --	 return 0;
    --END

	return [dbo].[RSDFN_IsValidIPV6Mask](@IPV6mask);
END
GO

-- =============================================
-- Function:    [RSDFN_IsValidIPV6Mask]
-- Description: This function validates IPV6 mask so that
--              it is consecutive 1s in binary.
-- Parameter:   @IPV6Mask - IPV4 or IPV6 net mask. Currently
--              only IPv4 or IPv6-compatible IPV4 addresses
--              are checked. It returns 1 for true IPV6 masks.
-- Returns:     A BIT. 1 is valid, 0 is invalid.
-- =============================================
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_IsValidIPV6Mask]') AND xtype = 'FN')
	DROP FUNCTION [dbo].[RSDFN_IsValidIPV6Mask]
GO
CREATE FUNCTION [dbo].[RSDFN_IsValidIPV6Mask](@IPV6Mask varbinary(16))
RETURNS BIT
AS
BEGIN
	DECLARE @valid BIT;
	DECLARE @masked BIT;
	DECLARE @iMask BIGINT;
	DECLARE @i INT;
	DECLARE @probe BIGINT;
	DECLARE @dummy BINARY(16);
	SET @valid = 1;
	-- Only check for IPV4 for now
	IF ([dbo].[RSDFN_IsIPAddressIPv4Compatible](@IPV6Mask) = 1)
	BEGIN
		IF (DATALENGTH(@IPV6Mask) = 4)
		BEGIN
			SET @iMask = CONVERT(BIGINT, @IPV6Mask);
		END
		ELSE
		BEGIN
			SET @iMask = CONVERT(BIGINT, SUBSTRING(@IPV6Mask, 13, 4));
		END

		-- 1111111111110000 good
		-- 1111111011110000 bad, the mask bits must be continous
		SET @masked = 0;
		SET @probe = 0x1;
		SET @i = 0;
		WHILE (@i < 32)
		BEGIN
			IF (@masked = 0)
			BEGIN
				IF (@iMask & @probe != 0)
				BEGIN
					SET @masked = 1;
				END
			END
			ELSE
			BEGIN
				IF (@iMask & @probe = 0)
				BEGIN
					SET @valid = 0;
					BREAK;
				END
			END
			-- all 0 mask is not allowed
			IF (@i = 31 AND @masked = 0)
			BEGIN
				SET @valid = 0;
				BREAK;
			END

			SET @i = @i + 1;
			SET @probe = @probe * 2; -- shift left bitwise
		END
	END

	RETURN @valid;
END
GO

----------------------------------------------------------------
--  END BUG 699813 - Detected systems, Top entry shows root
--  IPV6 subnet 00000000000000000 discovered.
----------------------------------------------------------------

----------------------------------------------------------------
--  START BUG 740034 - Add match to system override
----------------------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[RSDMoveToTreeMatchingCriteria]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  DROP TABLE [dbo].[RSDMoveToTreeMatchingCriteria]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_AddMoveToTreeCriteria]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_AddMoveToTreeCriteria]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_DeleteTreeCriteria]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_DeleteTreeCriteria]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_CreateMatchingComputerNameToUse]') )
  DROP FUNCTION [dbo].RSDFN_CreateMatchingComputerNameToUse
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_MatchAddToTreeCriteria]') )
  DROP FUNCTION [dbo].RSDFN_MatchAddToTreeCriteria
GO

----------------------------------------------------------------
--  END BUG 740034 - Add match to system override
----------------------------------------------------------------


----------------------------------------------------------------
--  BEGIN BUG 725379 - Ability to see sensor that detected system
----------------------------------------------------------------

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectedSystems]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDDetectedSystems]
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT  dsp.HostID,
	    dsp.DnsName,
        dsp.OSPlatform,
        dsp.OSFamily,
        dsp.OSVersion,
        dsp.Domain,
        dsp.NetbiosName,
        dsp.NetbiosComment,
        dsp.Users,
        dsp.AgentGUID,
        dsp.FriendlyName,
        dsp.Ignored,
        dsp.Comments,
        dsp.IPV4,
        dsp.IPV6,
        dsp.MAC,
        dsp.Exception,
        dsp.RogueAction,
        dsp.LastDetectedTime,
        dsp.RecordedTime,
        dsp.NewDetection,
        dsp.DeviceType,
        o.OUI,
        o.OrgName,
        CASE
            WHEN dsp.AgentGUID IS NULL THEN 0
            WHEN n.AgentGUID IS NULL THEN 1
            WHEN n.LastUpdate IS NOT NULL AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2
            WHEN n.LastUpdate IS NOT NULL AND n.LastUpdate >= DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN - 1
            ELSE 0
        END AS RogueState,
        CAST(
            CASE
                WHEN dsp.Exception = 0 AND dsp.AgentGUID IS NOT NULL AND n.LastUpdate IS NOT NULL
                    AND n.LastUpdate >= DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
                WHEN (aes.servername IS NOT NULL) THEN 1
                ELSE 0
            END AS BIT)
        AS Managed,
        CAST(
            CASE
                WHEN aes.ServerName IS NOT NULL THEN 0
                WHEN (dsp.AgentGUID IS NULL OR n.AgentGUID IS NULL OR n.LastUpdate IS NOT NULL
                    AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE())) AND dsp.Exception = 0
                    AND dsp.LastDetectedTime >= DATEADD(day, - 1 * c.LastSensorDetection, GETUTCDATE()) THEN 1
                ELSE 0
            END AS BIT)
        AS Rogue,
        CAST(
            CASE
                WHEN (dsp.AgentGUID IS NULL OR n.AgentGUID IS NULL OR n.LastUpdate IS NOT NULL
                    AND n.LastUpdate < DATEADD(day, - 1 * c.LastAgentCommunication, GETUTCDATE()))
                    AND dsp.Exception = 0 AND dsp.LastDetectedTime < DATEADD(day, - 1 * c.LastSensorDetection, GETUTCDATE()) THEN 1
                ELSE 0
            END AS BIT)
        AS Inactive,
        dst.SourceName AS DetectedSourceName,
        n.LastUpdate AS LastAgentCommunication,
        n.AgentVersion,
        CASE
            WHEN n.AutoID IS NOT NULL THEN eposi.ComputerName
            ELSE dsap.ServerName
        END AS ServerName,
        ec.Name AS ExceptionCategory
FROM dbo.RSDDetectedSystemProperties AS dsp
    LEFT OUTER JOIN dbo.RSDDetectedSystemAgentProperties AS dsap ON dsp.HostID = dsap.HostID
    LEFT OUTER JOIN dbo.RSDConfigurationAlternateEpoServers AS aes ON dsap.ServerName = aes.ServerName
    LEFT OUTER JOIN dbo.RSDExceptionCategories AS ec ON dsp.ExceptionCategoryID = ec.CategoryID
    LEFT OUTER JOIN dbo.EPOLeafNode AS n ON dsp.AgentGUID = n.AgentGUID
    LEFT OUTER JOIN dbo.RSDDetectedSourceType AS dst ON dsp.DetectedSourceType = dst.SourceType
    LEFT OUTER JOIN dbo.OUIs AS o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
    CROSS JOIN dbo.RSDConfiguration AS c
    CROSS JOIN dbo.EPOServerInfo AS eposi
WHERE (dsp.Ignored = 0) AND (c.ID = 1)
GO

----------------------------------------------------------------
--  END BUG 725379 - Ability to see sensor that detected system
----------------------------------------------------------------

----------------------------------------------------------------
--  BUG 757247 - Collision between Server Active Status, and Election Active Status
----------------------------------------------------------------

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensors]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDSensors]
GO

CREATE VIEW [dbo].[RSDSensors]
AS
SELECT  RSDSensorProperties.SensorID,
        RSDSensorProperties.SensorName,
        RSDSensorProperties.LastCommunicationTime,
        RSDSensorProperties.AgentGUID,
        RSDSensorProperties.SensorType,
        RSDSensorProperties.SensorVersion,
        RSDSensorProperties.Description,
        RSDSensorProperties.Started,
        RSDSensorProperties.ComputerName,
        RSDSensorProperties.FirstCommunicationTime,
        RSDSensorProperties.FirstRecordedTime,
        RSDSensorProperties.LastRecordedTime,
        RSDSensorProperties.LastStartedTime,
        RSDSensorProperties.LastStoppedTime,
        [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, GETUTCDATE()) as Status,
        [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](RSDSensorProperties.AgentGUID) as Installed
FROM    RSDSensorProperties
GO

----------------------------------------------------------------
--  END BUG 757247 - Collision between Server Active Status, and Election Active Status
----------------------------------------------------------------


----------------------------------------------------------------
--  BEGIN BUG 740036 - Ability to see sensor that detected system
----------------------------------------------------------------
-- This tries to select and match the incoming detected system with existing managed machines
EXEC EPOCore_DropStoredProc N'RSDSP_MatchManagedSystems';
GO
CREATE PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16)
)
AS
BEGIN
    declare @managedMatching    int;

    -- The Configuration ID by default should always be 1
    select @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration]
        where [RSDConfiguration].[ID] = 1;

    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    declare @m_AgentGUID          uniqueidentifier;

    declare @found bit;
	declare @cnt int;
	declare @done bit;
	declare @results table (
		LeafNodeID		int,
		AgentGUID       uniqueidentifier,
		MAC             nvarchar(100),
		ComputerName    nvarchar(255),
		Domain          nvarchar(255),
		DnsName         nvarchar(255),
		IPV4            int,
		IPV6            binary (16)
	);

    set @found = 0;
	set @done = 0;
	set @cnt = 0;

    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin

		insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
			select [EPOLeafNode].[AutoID],
				   @AgentGUID,
				   [EPOComputerProperties].[NetAddress],
				   [EPOComputerProperties].[ComputerName],
				   [EPOComputerProperties].[DomainName],
				   [EPOComputerProperties].[IPHostName],
				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
				   [EPOComputerProperties].[IPV6]
			from [EPOLeafNode] WITH (NOLOCK)
				inner join [EPOComputerProperties] WITH (NOLOCK)
				on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
			where [EPOLeafNode].[AgentGUID] = @AgentGUID;

		select @cnt = count(*) from @results;
		if (@cnt = 1)
		begin
            set @done = 1;
			set @m_AgentGUID = @AgentGUID;
		end

		-- In this case, we have already associated the AgentGUID to a ManagedSystem, so we're good
		-- unless we decide we want to update the DetectedSystem entry with known values from the ManagedSystem
		-- If more than one AgentGUID matches, we've got other problems...
    end

	if (@done = 0 and @MAC is not null and @useMAC = 1)
	begin
		if (@found = 0)
		begin
		    set @MAC = upper(@MAC);

			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where upper([dbo].[EPOComputerProperties].[NetAddress]) = @MAC;

			select @cnt = count(*) from @results;

			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		-- Since this is the first possible case, there is no "else" here...
	end

	if (@done = 0 and @ComputerName is not null and @Domain is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName
					and [dbo].[EPOComputerProperties].[DomainName] = @Domain;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName and R.Domain <> @Domain;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[IPHostName] = @DnsName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.DnsName <> @DnsName;

			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end

	-- This is the IP Address check, it's gonna be a little nasty...
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if ([dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
				if (@IPV4 is not null)
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
						from [EPOLeafNode] WITH (NOLOCK)
							inner join [EPOComputerProperties] WITH (NOLOCK)
							on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
				end
				else
				begin
					insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
						select [EPOLeafNode].[AutoID],
							   [EPOLeafNode].[AgentGUID],
							   [EPOComputerProperties].[NetAddress],
							   [EPOComputerProperties].[ComputerName],
							   [EPOComputerProperties].[DomainName],
							   [EPOComputerProperties].[IPHostName],
            				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
							   [EPOComputerProperties].[IPV6]
					from [EPOLeafNode] WITH (NOLOCK)
						inner join [EPOComputerProperties] WITH (NOLOCK)
						on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
						where [dbo].[EPOComputerProperties].[IPV6] = @IPV6;
				end

				select @cnt = count(*) from @results;
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete R from @results as R where R.IPV4 <> @IPV4;
				end
				else
				begin
					delete R from @results as R where R.IPV6 <> @IPV6;
				end

    			select @cnt = count(*) from @results;
				if (@cnt = 0)
				begin
					set @done = 1;
				end
				if (@cnt = 1)
				begin
					set @done = 1;
					select @m_AgentGUID = AgentGUID from @results;
				end
				if (@cnt > 1)
				begin
					set @found = 1;
				end
			end
		end
	end

	-- Check for Hostname only!
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		-- If we haven't found anything yet, insert this new selection into the DB
		if (@found = 0)
		begin
			insert into @results (LeafNodeID, AgentGUID, MAC, ComputerName, Domain, DnsName, IPV4, IPV6)
				select [EPOLeafNode].[AutoID],
					   [EPOLeafNode].[AgentGUID],
					   [EPOComputerProperties].[NetAddress],
					   [EPOComputerProperties].[ComputerName],
					   [EPOComputerProperties].[DomainName],
					   [EPOComputerProperties].[IPHostName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt]([EPOComputerProperties].[IPV6]),
					   [EPOComputerProperties].[IPV6]
				from [EPOLeafNode] WITH (NOLOCK)
					inner join [EPOComputerProperties] WITH (NOLOCK)
					on [EPOLeafNode].[AutoID] = [EPOComputerProperties].[ParentID]
				where [dbo].[EPOComputerProperties].[ComputerName] = @ComputerName;

			select @cnt = count(*) from @results;
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
		else
		begin
			delete R from @results as R where R.ComputerName <> @ComputerName;
			select @cnt = count(*) from @results;

			if (@cnt = 0)
			begin
				set @done = 1;
			end
			if (@cnt = 1)
			begin
				set @done = 1;
				select @m_AgentGUID = AgentGUID from @results;
			end
			if (@cnt > 1)
			begin
				set @found = 1;
			end
		end
	end


	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID
		and (AgentGUID is null OR AgentGUID <> @m_AgentGUID OR RogueAction is null OR RogueAction <> 0);
	end
END
GO

----------------------------------------------------------------
--  BEGIN BUG 740036
----------------------------------------------------------------

----------------------------------------------------------------
--  BEGIN BUG 760041
----------------------------------------------------------------
EXEC EPOCore_DropFunction N'RSDFN_CountSensorsForSubnet';
GO

CREATE FUNCTION [dbo].[RSDFN_CountSensorsForSubnet]
(
	@SubnetID int,
	@SensorStatus int
)
RETURNS int
AS
BEGIN
	declare @cnt int;

	select @cnt = count(*) from RSDSensorToSubnet
	left join RSDSensors on RSDSensors.SensorID = RSDSensorToSubnet.SensorID
	where RSDSensorToSubnet.SubnetID = @SubnetID and RSDSensors.Status = @SensorStatus

	return @cnt;
END
GO
----------------------------------------------------------------
--  END BUG 760041
----------------------------------------------------------------

----------------------------------------------------------------
--  BEGIN BUG 740036
----------------------------------------------------------------


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_GetNewDetectedSystemEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_GetNewDetectedSystemEvents]
GO


CREATE PROCEDURE [dbo].[RSDSP_GetNewDetectedSystemEvents]
(
	@WhereClause	ntext
)
AS
BEGIN
	SET NOCOUNT ON;

    -- Create the Where clause for the timestamp, so we're only pulling events we haven't processed yet...
    declare @WhereTime nvarchar(128);
	set @WhereTime = 'RecordedTime > (select LastProcessedUTC from [dbo].[EPONotificationProcessed] where [Type] = N''rsdAddDetectedSystemEvent'')';

	-- If the where clause is null, then we must want all the events since the last time
	-- the Notification Threat Event triggered...  So, just get ALL events
	declare @LastProcessed datetime;
	set @LastProcessed = GETUTCDATE();
	if (@WhereClause is null)
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName
			from RSDDetectedSystems where ' + @WhereTime);
	end
	else
	begin
		exec ('select HostID, DnsName, OSPlatform, OSFamily, OSVersion, Domain, NetbiosName, NetbiosComment, Users, AgentGUID,
		    FriendlyName, Ignored, Comments, IPV4, IPV6, MAC, Exception, RogueAction, LastDetectedTime, OrgName, OUI, NewDetection,
		    RogueState, Managed, Rogue, Inactive, DetectedSourceName, LastAgentCommunication, AgentVersion, ServerName
			from RSDDetectedSystems where (' + @WhereTime + ') and (' + @WhereClause + ')' );
	end

    exec [dbo].[RSDSP_UpdateNewDetectedSystemEventCheck] @LastProcessed;

END
GO

----------------------------------------------------------------
--  END BUG 740036
----------------------------------------------------------------
