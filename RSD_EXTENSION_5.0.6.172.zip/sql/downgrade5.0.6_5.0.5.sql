
IF OBJECT_ID('RSDSP_CreateAgentUpdateDetection') IS NOT NULL
BEGIN
	DROP PROCEDURE [dbo].[RSDSP_CreateAgentUpdateDetection]
END;

GO

/****** Object:  StoredProcedure [dbo].[RSDSP_CreateAgentUpdateDetection]    Script Date: 3/18/2020 1:48:01 PM ******/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE PROCEDURE [dbo].[RSDSP_CreateAgentUpdateDetection]
(
    @LeafNodeID   int,
    @AgentGUID    uniqueidentifier,
	@DnsName			nvarchar(255),
	@OSPlatformStr		nvarchar(100),
	@OSVersion          nvarchar(128),
	@Domain             nvarchar(255),
	@ComputerName       nvarchar(255),
	@Users              nvarchar(128),
	@IPV6               binary(16),
	@IPV6mask           binary(16),
	@IPV6subnet         binary(16),
	@MACStr             nvarchar(100)
)
AS
BEGIN

	declare @NetbiosName		nvarchar(16);
	declare @OSPlatform         nvarchar(25);
	declare @MAC                nvarchar(12);
	declare @DetectedTime       datetime;
	declare @SourceType         nvarchar(100);
    declare @DeviceType         nvarchar(100);

	declare @OutputHostID		int;
	declare @OutputNewDetection bit;

    if (@IPV6 is null)
    begin
        return;
    end

	set @NetbiosName = SUBSTRING(@ComputerName,1,16);

    if (@MACStr is not null)
    begin
        -- Handle solaris agent problem (bug 449222)
        set @MAC = [dbo].[RSDFN_ValidateMACString](@MACStr);
    end

	if (@OSPlatformStr like '%Windows%')
	begin
		set @OSPlatform = 'Windows'
	end
	else if (@OSPlatformStr like '%Mac%' or @OSPlatformStr like '%Apple%')
	begin
		set @OSPlatform = 'Macintosh'
	end
	else if (@OSPlatformStr like '%Linux%')
	begin
		set @OSPlatform = 'Linux'
	end
	else if (@OSPlatformStr like '%BSD%')
	begin
		set @OSPlatform = 'BSD'
	end
	else if (@OSPlatformStr like '%IRIX%')
	begin
		set @OSPlatform = 'IRIX'
	end
	else if (@OSPlatformStr like '%HP-UX%')
	begin
		set @OSPlatform = 'HP-UX'
	end
	else if (@OSPlatformStr like '%AIX%')
	begin
		set @OSPlatform = 'AIX'
	end
	else if (@OSPlatformStr like '%Netware%' or @OSPlatformStr like '%Novell%')
	begin
		set @OSPlatform = 'Novell'
	end
	else if (@OSPlatformStr like '%Sun%' or @OSPlatformStr like '%Solaris%')
	begin
		set @OSPlatform = 'Sun'
	end
	else if (@OSPlatformStr like '%Unix%')
	begin
		set @OSPlatform = 'Unix'
	end
	else
	begin
		set @OSPlatform = 'Unknown'
	end

	if (@OSPlatform <> 'Windows')
	begin
		set @NetbiosName = null;
		set @Domain = null;
	end


    if (@OSPlatform = 'Unknown')
    begin
        set @DeviceType = 'unknown';
    end
    else
    begin
        set @DeviceType = 'computer';
    end


	set @DetectedTime = GETUTCDATE();

	set @SourceType = 'epo.agent';

	exec [dbo].[RSDSP_UpdateDetectedSystems] @DnsName, @OSPlatform, null, @OSVersion, @Domain, @NetbiosName,
		null, @Users, @AgentGUID, null, @IPV6, @MAC, @DetectedTime, @DeviceType, @LeafNodeID, @SourceType, null,
		N'detectedSystem', null, 0, @OutputHostID output, @OutputNewDetection output;

	exec [dbo].[RSDSP_UpdateInterfaces] @OutputHostID, @MAC, null, null, null, @IPV6, @IPV6mask, @IPV6subnet,
		@DetectedTime, @LeafNodeID, @SourceType, null;

END
GO

-----------------------------------------------------------------------------------------------------------------------
--START MVR-156: Rollback of changes to RSD table RSDInterfaceProperties for indexing and PK constraints.
IF  EXISTS (SELECT 1 FROM SYS.INDEXES WHERE NAME = 'IX_RSDInterfaceProperties_IPV6' AND OBJECT_ID = OBJECT_ID('RSDInterfaceproperties'))
BEGIN  
	DROP INDEX IX_RSDInterfaceProperties_IPV6 ON RSDInterfaceproperties;
END;
GO
--End MVR-156
-----------------------------------------------------------------------------------------------------------------------
--START MVR-160: Revert the PK constraint back to original State.
IF EXISTS (SELECT 1 FROM  INFORMATION_SCHEMA.TABLE_CONSTRAINTS  WHERE CONSTRAINT_NAME='PK_RSDUnmanagedSystemsLink' AND TABLE_NAME='RSDUnmanagedSystemsLink')
BEGIN 
	ALTER TABLE RSDUnmanagedSystemsLink DROP CONSTRAINT PK_RSDUnmanagedSystemsLink;
END;
GO

IF NOT EXISTS(SELECT 1 FROM  INFORMATION_SCHEMA.TABLE_CONSTRAINTS  WHERE CONSTRAINT_NAME='PK_RSDUnmanagedSystemsLink' AND TABLE_NAME='RSDUnmanagedSystemsLink')
BEGIN  
	ALTER TABLE RSDUnmanagedSystemsLink ADD CONSTRAINT PK_RSDUnmanagedSystemsLink PRIMARY KEY(DetectedSystemHostID,EPOLeafNodeID) ;
END;
GO

--Drop Index IX_RSDSubnetProperties_IPV6_IPV6mask added as part of POC on RSDSubnetProperties.
IF  EXISTS (SELECT 1 FROM SYS.INDEXES WHERE NAME='IX_RSDSubnetProperties_IPV6_IPV6mask' AND OBJECT_ID = OBJECT_ID('RSDSubnetProperties'))
BEGIN
	DROP INDEX IX_RSDSubnetProperties_IPV6_IPV6mask ON dbo.RSDSubnetProperties;
END;
GO

--Drop Index IX_RSDDetectedSource_IDs added as part of POC on RSDDetectedSource.
IF  EXISTS (SELECT 1 FROM SYS.INDEXES WHERE NAME = 'IX_RSDDetectedSource_IDs' AND OBJECT_ID = OBJECT_ID('RSDDetectedSource'))
BEGIN
	DROP INDEX IX_RSDDetectedSource_IDs ON dbo.RSDDetectedSource;

END;
GO
--Drop Index IX_RSDDetectedSystemProperties_NetbiosNameDetectionType added as part of POC on RSDDetectedSystemProperties.
IF  EXISTS (SELECT 1 FROM SYS.INDEXES WHERE NAME = 'IX_RSDDetectedSystemProperties_NetbiosNameDetectionType' AND OBJECT_ID = OBJECT_ID('RSDDetectedSystemProperties'))
BEGIN 
	DROP INDEX IX_RSDDetectedSystemProperties_NetbiosNameDetectionType ON RSDDetectedSystemProperties;
END;
GO
--Drop Index IX_RSDInterfaceProperties_IPV4 added as part of POC on RSDInterfaceProperties. 
IF  EXISTS (SELECT 1 FROM SYS.INDEXES WHERE NAME = 'IX_RSDInterfaceProperties_IPV4' AND object_id = OBJECT_ID('RSDInterfaceProperties'))
BEGIN
	DROP INDEX IX_RSDInterfaceProperties_IPV4 ON RSDInterfaceProperties;
	
END;
GO
--End MVR-160
-----------------------------------------------------------------------------------------------------------------------
--START MVR-163: Revert changes to RSD trigger TR_RSDSubnetProperties_OnInsert for noblocking RSD queries.
ALTER TRIGGER [TR_RSDSubnetProperties_OnInsert]
   ON  [dbo].[RSDSubnetProperties]
   FOR INSERT, UPDATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- invoke user-definedtranslation function for all all affected IP address columns
	-- get the inserted
	IF (UPDATE(IPV6) OR UPDATE(IPV6Mask))
	BEGIN
		IF (UPDATE(IPV6)) 
		BEGIN
			-- Only update the IPv4 field if the v6 address is IPv4 compatible...
			UPDATE RSDSubnetProperties
			SET IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6)
			FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
			ON A.SubnetID = B.SubnetID
			WHERE (A.IPV6 is not null )
			AND [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6) = 1;
		END

		IF (UPDATE(IPV6mask)) 
		BEGIN
			-- Only update the IPv4 field if the v6 address is IPv4 compatible...
			UPDATE B
			SET IPV4mask = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6mask)
			FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
			ON A.SubnetID = B.SubnetID
			WHERE (A.IPV6mask is not null )
			AND [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6mask) = 1;
		END

		-- all entries need to be range-updated
		UPDATE B
		SET IPV6Start = [dbo].[RSDFN_IPV6SubnetAddrStart](B.IPV6, B.IPV6Mask),
		 IPV6End = [dbo].[RSDFN_IPV6SubnetAddrEnd](B.IPV6, B.IPV6Mask)
		FROM inserted AS A INNER JOIN RSDSubnetProperties AS B
		ON A.SubnetID = B.SubnetID
		WHERE (B.IPV6 is not null and B.IPV6mask is not null);
	END
END
GO

ALTER  TRIGGER [dbo].[TR_RSDInterfaceProperties_OnInsert]  
   ON  [dbo].[RSDInterfaceProperties]  
   FOR INSERT, UPDATE  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  
 -- invoke user-defined translation function for all all affected IP address columns  
 -- get the inserted  
  
 IF (UPDATE(IPV6))  
 BEGIN  
     -- Only update the IPv4 field if the v6 address is IPv4 compatible...  
        UPDATE RSDInterfaceProperties   
        SET IPV4 = [dbo].[RSDFN_ConvertIPV6BinaryToInt](B.IPV6)  
        FROM inserted AS A INNER JOIN RSDInterfaceProperties  AS B WITH(NOLOCK)  
        ON A.InterfaceID = B.InterfaceID where A.IPV6 is not null  
            and [dbo].[RSDFN_IsIPAddressIPv4Compatible] (A.IPV6) = 1;  
 END  
END  
GO
--End MVR-163
-----------------------------------------------------------------------------------------------------------------------
--Trigger optimized :TR_RSDSubnetProperties_OnUpdate
ALTER TRIGGER [dbo].[TR_RSDSubnetProperties_OnUpdate] ON [dbo].[RSDSubnetProperties]
AFTER UPDATE
AS
BEGIN
	-- squelch rowcount reports
	SET NOCOUNT ON;

	IF (UPDATE(Ignored))
	BEGIN
		-- build subnets that changed ignored state to 1 from 0
		DECLARE @tblSubnets TABLE(SubnetID int);
		INSERT INTO @tblSubnets(SubnetID)
			SELECT inserted.SubnetID
			FROM inserted join deleted
			ON (inserted.SubnetID = deleted.SubnetID)
			AND (inserted.Ignored = 1)
			AND (deleted.Ignored = 0);

		-- delete all detected systems properties that have no interfaces
		--  being managed by non-ignored subnets.
		IF (@@rowcount != 0)
		BEGIN
			DELETE rsdDSP
			FROM RSDDetectedSystemProperties rsdDSP
			INNER JOIN RSDInterfaceProperties rsdIP	ON (rsdIP.HostID = rsdDSP.HostID)
			INNER JOIN @tblSubnets A ON (rsdIP.SubnetID = A.SubnetID)
			WHERE NOT EXISTS
			(
				SELECT 1
				FROM RSDSubnetProperties rsdSP
				WHERE rsdSP.SubnetID = rsdIP.SubnetID
				AND (rsdSP.Ignored = 0)
			)
		END
	END
END
GO
-----------------------------------------------------------------------------------------------------------------------


