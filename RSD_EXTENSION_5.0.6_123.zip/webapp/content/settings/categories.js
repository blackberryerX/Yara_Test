/*
 * Copyright (c) 2004 - 2010 McAfee, Inc.  All Rights Reserved.
 */

function addRowCallback(val)
{
	var vid = val.id.lastIndexOf("_");
	var i = val.id.substring(vid+1);
	OrionForm.setFieldRequired("name_"+i, true);
    
	OrionForm.revalidate();
}

function removeRowCallback()
{
    //alert("Removed: "+val.id);
}