-------------------------------------------------------------------------------
-- update4.7.0-4.7.1.sql
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- BZ727282
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- RSDFN_IsInDelimitedList
-- Determines if an item is in the delimited list
-- Parameters:
--   @Item		nvarchar(255) a string item to be searced for
--   @List		nvarchar(255) list of items in the form of delimited string
--   @Delimiter nchar(1) the delimiter
-- Return Value:
--   Retuns bit 1 if found, 0 if not found
EXEC EPOCore_DropFunction N'RSDFN_IsInDelimitedList';
GO
CREATE FUNCTION [dbo].[RSDFN_IsInDelimitedList]
(
    @Item nvarchar(255),
	@List nvarchar(255),
	@Delimiter nchar(1) = ';'
)
RETURNS bit
AS
BEGIN
    declare @paddedItem nvarchar(255);
    declare @paddedList nvarchar(255);
	set @paddedItem = @Delimiter + @Item + @Delimiter;
	set @paddedList = @Delimiter + @List + @Delimiter;
	
    declare @ret bit;
    set @ret = 0;

	if (CHARINDEX(@paddedItem, @paddedList) <> 0)
	begin
            set @ret = 1;
        end

    return @ret;
END
GO
-- END RSDFN_IsInDelimitedList
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- RSDDetectedSystems
if exists (select * from sys.views where object_id = object_id(N'.[dbo].[RSDDetectedSystems]'))
drop view [dbo].[RSDDetectedSystems]
GO
CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT
	dsp.HostID,
	dsp.DnsName,
	dsp.OSPlatform,
	dsp.OSFamily,
	dsp.OSVersion,
	dsp.Domain,
	dsp.NetbiosName,
	dsp.NetbiosComment,
	dsp.Users,
	dsp.AgentGUID,
	dsp.FriendlyName,
	dsp.Ignored,
	dsp.Comments,
	dsp.IPV4,
	dsp.IPV6,
	dsp.MAC,
	dsp.Exception,
	dsp.RogueAction,
	dsp.LastDetectedTime,
	dsp.RecordedTime,
	dsp.NewDetection,
	dsp.DeviceType,
	[dbo].[RSDFN_GetLastDetectedSourceId](dsp.HostId) As SourceID,
	o.OUI,
	o.OrgName,
	CASE
		WHEN dsp.AgentGUID IS NULL THEN 0
		WHEN ISNULL(ac.AgentCount, 0) = 0 THEN 1	-- This is an "Alien Agent"
		WHEN n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2	-- This is a "Dead Agent"
		WHEN n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN -1	-- This is a "Managed" machine
		ELSE 0
	END	AS RogueState,
	CAST
	( CASE
		WHEN dsp.Exception = 0
			AND	dsp.AgentGUID IS NOT NULL
			AND	n.LastUpdate IS NOT NULL
			AND	n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
		WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
				) is not null
			) THEN 1
		ELSE 0
	END AS BIT ) AS Managed,
	CAST
	( CASE
        WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
			  ) is not null
			) THEN 0
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime >= DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN	1
		ELSE	0
	END AS BIT ) AS Rogue,
	CAST
	( CASE
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime < DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN 1
		ELSE 0
	END	AS BIT ) AS Inactive,
	dst.SourceName AS DetectedSourceName,
	n.LastUpdate AS LastAgentCommunication,
	n.AgentVersion AS AgentVersion,
	CASE
		WHEN n.AutoID IS not null THEN (select top 1 ComputerName from [dbo].[EPOServerInfo])
		ELSE (select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID)
	END AS ServerName,
	(select [Name] from [dbo].[RSDExceptionCategories] where CategoryID = dsp.ExceptionCategoryID)
	AS ExceptionCategory

FROM
(
	dbo.RSDDetectedSystemProperties	dsp
	LEFT OUTER JOIN	dbo.EPOLeafNode n ON dsp.AgentGUID = n.AgentGUID
	LEFT OUTER JOIN	dbo.RSDDetectedSourceType dst ON dsp.DetectedSourceType	= dst.SourceType
	LEFT OUTER JOIN	dbo.OUIs o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
	LEFT OUTER JOIN
	(
		SELECT AgentGUID, COUNT(*) AS AgentCount FROM dbo.EPOLeafNode WHERE AgentGUID IS NOT NULL GROUP BY AgentGUID
	) ac ON dsp.AgentGUID = ac.AgentGUID
)
CROSS JOIN
(
	SELECT * FROM dbo.RSDConfiguration WHERE ID = 1
) c
WHERE dsp.Ignored=0;
GO
-- END RSDDetectedSystems
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- END BZ727282
-------------------------------------------------------------------------------
