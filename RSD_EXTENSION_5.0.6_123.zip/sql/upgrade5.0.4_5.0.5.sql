-- Bug 1156027 - Sensor Version is not removed when product is Uninstalled.

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RSDFN_ManagedSystemSensorVersion]') )
	DROP FUNCTION [dbo].[RSDFN_ManagedSystemSensorVersion]
GO

CREATE FUNCTION [dbo].[RSDFN_ManagedSystemSensorVersion]
(
    @AgentGUID      uniqueidentifier
)
RETURNS nvarchar (255)
AS
BEGIN    
	declare @SensorVersion nvarchar(255);
	set @SensorVersion = 'Unknown';
	declare @hasSensor bit;
    
	set @hasSensor = [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](@AgentGUID);
	
	if (@hasSensor <> 0)			
		select @SensorVersion = SensorVersion from [dbo].[RSDSensorProperties] where AgentGUID = @AgentGUID;
	
	return @SensorVersion;
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateDetectedSystems]
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystems]
(
    @DnsName					nvarchar(255),
    @OSPlatform					nvarchar(100),
    @OSFamily					nvarchar(128),
    @OSVersion					nvarchar(128),
    @Domain						nvarchar(255),
    @NetbiosName				nvarchar(16),
    @NetbiosComment				nvarchar(100),
    @Users						nvarchar(128),
    @AgentGUID					uniqueidentifier,
    @IPV4						int,
    @IPV6						varbinary (16),
    @MAC						nvarchar(12),
    @DetectedTime				datetime,
    @DeviceType					nvarchar(100),
    @SourceID					int,
    @SourceType					nvarchar(100),
    @ExternalID					nvarchar(1000),
    @DetectionType              nvarchar(255),
    @ExternalFriendlyName		nvarchar(255),
    @MatchingOverride       	int,
    @OutputHostID				int OUTPUT,
    @OutputNewDetection			bit OUTPUT
)
AS
BEGIN
    declare @NewDetection bit;
    set @NewDetection = 0;

    declare @FriendlyName nvarchar(255);
    declare @HostID int;

   if (@SourceType = 'mam.broadcast')
	begin
            -- touch sensor key whan sensor reconnected

            UPDATE [dbo].[RSDSensorKeys] 
            SET lastRequestTime = GETUTCDATE() 
            WHERE agentGUID = (select top 1 AgentGUID from RSDSensorProperties where SensorID=@SourceID);

        end

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);

		-- bug 431315 - if MAC is from a VPN or other "exclude this" list, then don't use it (set to null)
		declare @OUI nvarchar(6);
		set @OUI = SUBSTRING(@MAC, 0, 7);

		declare @vendorIdCount int;
		select @vendorIdCount = count(*) from EPOVirtualMacVendor where VendorID = @OUI;
		if (@vendorIdCount > 0)
		begin
			set @MAC = NULL;
		end
    end;

    if (DATALENGTH(@IPV6) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @IPV6;
    end

    -- Begin fix for 457424 / 457673
	-- If the interface is in an ignored subnet, do not add the interface
	-- and make sure we don't end up orphaning a detected system object
    declare @OutSubnetID int;
    if (@IPV6 is not null)
    begin
        exec RSDSP_FindSubnetForIPAddress @IPV6, @OutSubnetID output
    end
	-- If the subnetid is not null and the associated subnet is "ignored", then we don't want to continue
    if (@OutSubnetID is not null and exists(select 1 from RSDSubnetProperties where SubnetID = @OutSubnetID and Ignored = 1))
	begin
		-- We're going to bail out of here now
		set @OutputHostID = 0;
		set @OutputNewDetection = 0;
		return;
	end
	-- End fix for 457424 / 457673

	-- Match detected systems
	exec RSDSP_MatchDetectedSystems @AgentGUID, @SourceID, @SourceType, @ExternalID,
		@MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @DetectionType,
		@MatchingOverride, @HostID output;

	-- if the SourceType is RSD 5.0 then we use the given OS Platform 
	-- to lookup the relevant Platform/Family/Version from the RSDLookupOSName table
	if (@SourceType = 'mam.broadcast')
	begin
            exec RSDSP_LookupMAMOSInfo @OSPlatform, @OSPlatform output, @OSFamily output, @OSVersion output, @DeviceType output
	end
	
    -- Keep track of when this item was recorded
    declare @RecordedTime datetime;
    set @RecordedTime = GETUTCDATE();

    -- If this identity algoritm returns a match, then update the DetectedSystem,
    -- Interfaces, DetectedSource, and Status with the new data
    if (@HostID is not null)
    begin
        -- We need to get the existing data and replace all non-null values with updated data
        declare @_DnsName            nvarchar(255);
        declare @_OSPlatform         nvarchar(25);
        declare @_OSFamily           nvarchar(128);
        declare @_OSVersion          nvarchar(128);
        declare @_Domain             nvarchar(255);
        declare @_NetbiosName        nvarchar(16);
        declare @_NetbiosComment     nvarchar(100);
        declare @_Users              nvarchar(128);
        declare @_AgentGUID          uniqueidentifier;
        declare @_IPV4               int;
        declare @_IPV6               varbinary (16);
        declare @_MAC                nvarchar(12);
        declare @_DetectedTime       datetime;
        declare @_DeviceType         nvarchar(100);
        declare @_SourceType         nvarchar(100);
        declare @forceReplacePlatform int;

        select TOP 1 @_DnsName = DnsName,
               @_OSPlatform = OSPlatform,
               @_OSFamily = OSFamily,
               @_OSVersion = OSVersion,
               @_Domain = [Domain],
               @_NetbiosName = NetbiosName,
               @_NetbiosComment = NetbiosComment,
               @_Users = Users,
               @_AgentGUID = AgentGUID,
               @_IPV4 = IPV4,
               @_IPV6 = IPV6,
               @_MAC = MAC,
               @_DetectedTime = LastDetectedTime,
               @_DeviceType = DeviceType,
               @_SourceType = DetectedSourceType
        from [dbo].[RSDDetectedSystemProperties]
        where HostID = @HostID;

		if (@DnsName is null or LEN(@DnsName) = 0)
			set @DnsName = @_DnsName;
			
		set @forceReplacePlatform = 1;                  
		-- force change platform in case os family found and different for mam.broadcast      
		if (@SourceType = 'mam.broadcast' and (@OSFamily is not null AND @OSFamily != @_OSFamily)) 
			set  @forceReplacePlatform = 1;
		else 
			if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
				set @forceReplacePlatform = 0;
					  
		-- Bug 1155740 - To handle the extension related issue documented in 1155740. Basically, if the RSD sensor sends OSPlatform as blank for an existing device in 
		-- the EPO DB, the rsddata32 extension calls a stored procedure. This stored procedure does not update OSPlatform in the DB, but only the Device Type is updated 
		-- in the EPO DB. This leads to inconsistencies in Device Type and OSPlatform details on EPO detected systems page.
		
		-- if(@forceReplacePlatform = 0)  
		  -- set @OSPlatform = @_OSPlatform

                -- if platform not changed we could keep non empty value
		if ((@OSPlatform = @_OSPlatform) AND  (@OSFamily is null or LEN(@OSFamily) = 0))  
			set @OSFamily = @_OSFamily;

                -- if platform and  family not changed we could keep non empty value
		if (((@OSPlatform = @_OSPlatform) AND (@OSFamily = @_OSFamily)) 
                                        AND (@OSVersion is null or LEN(@OSVersion) = 0))
			set @OSVersion = @_OSVersion;

		if (@Domain is null or LEN(@Domain) = 0)
			set @Domain = @_Domain;

		if (@NetbiosName is null or LEN(@NetbiosName) = 0)
			set @NetbiosName = @_NetbiosName;

		if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
			set @NetbiosComment = @_NetbiosComment;

		if (@Users is null or LEN(@Users) = 0)
			set @Users = @_Users;

        set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);

		if (@MAC is null or LEN(@MAC) = 0)
			set @MAC = @_MAC;

        set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

		if (@DeviceType is null or LEN(@DeviceType) = 0)
			set @DeviceType = @_DeviceType;

		if (@ExternalFriendlyName is null or LEN(@ExternalFriendlyName) = 0)
			set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);
		else
			set @FriendlyName = @ExternalFriendlyName

        update [dbo].[RSDDetectedSystemProperties]
        set DnsName = @DnsName,
            OSPlatform = @OSPlatform,
            OSFamily = @OSFamily,
            OSVersion = @OSVersion,
            [Domain] = @Domain,
            NetbiosName = @NetbiosName,
            NetbiosComment = @NetbiosComment,
            Users = @Users,
            AgentGUID = @AgentGUID,
            IPV4 = @IPV4,
            IPV6 = @IPV6,
            MAC = @MAC,
            LastDetectedTime = @DetectedTime,
            FriendlyName = @FriendlyName,
            DetectedSourceType = @SourceType,
            RecordedTime = @RecordedTime,
            DeviceType = @DeviceType,
            NewDetection = 0,
            DetectionType = @DetectionType,
            ExternalFriendlyName = @ExternalFriendlyName,
            MatchingOverride = @MatchingOverride
        where HostID = @HostID;
    end
    else
    begin
        -- Friendly name is determined by the following, whichever one is not null
		set nocount on;

		
		if (@ExternalFriendlyName is null or LEN(@ExternalFriendlyName) = 0)
			set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);
		else
			set @FriendlyName = @ExternalFriendlyName

        -- Otherwise, add a new row to the DetectedSystems, Interfaces, Status,
        -- DetectedSource and if the RDSSubnets doesn't have associated subnets
        -- we'll need to add in subnet tables, too...
        insert into [dbo].[RSDDetectedSystemProperties] (DnsName, OSPlatform, OSFamily, OSVersion, [Domain],
            NetbiosName, NetbiosComment, Users, AgentGUID, FriendlyName, IPV4, IPV6, MAC,
            LastDetectedTime, DetectedSourceType, Ignored, RecordedTime, DeviceType, NewDetection,
            DetectionType, ExternalFriendlyName, MatchingOverride)
        values (@DnsName, @OSPlatform, @OSFamily, @OSVersion, @Domain,
            @NetbiosName, @NetbiosComment, @Users, @AgentGUID, @FriendlyName, @IPV4, @IPV6, @MAC,
            @DetectedTime, @SourceType, 0, @RecordedTime, @DeviceType, 1, @DetectionType,
            @ExternalFriendlyName, @MatchingOverride);
        select @HostID = SCOPE_IDENTITY();

        set @NewDetection = 1;
    end

	-- Updates the Detected System with the matching ManagedSystem, if it exists...
	 exec RSDSP_MatchManagedSystems @HostID, @AgentGUID, @MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @DetectionType

	-- if the external id is provided, use it as further qualification when performing
	--  the detected source update. otherwise use the base info.
	if (@HostID IS NOT NULL)
	begin
		declare @dsid int;
		if (@ExternalID is not null)
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType)
				and (ExternalID = @ExternalID);
		end
		else
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType);
		end

		-- update source record timestamps
		if (@dsid is not null)
		begin
			update RSDDetectedSource
				set LastDetectedTime = @DetectedTime, LastRecordedTime = @RecordedTime
				where AutoID = @dsid;
		end
		else
		begin
			-- add  detected source record, which couldn't have existed prior because there was no hostid.
			insert into RSDDetectedSource (HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			values (@HostID, @SourceID, @SourceType, @ExternalID, @DetectedTime, @DetectedTime, @RecordedTime, @RecordedTime);
		end
	end

    -- Gonna need a second stored procedure for the interfaces and subnets, so return the HostID for the
    -- next round of inserts
	set @OutputHostID = @HostID;
    set @OutputNewDetection = @NewDetection;
END
GO

IF NOT EXISTS(select * from dbo.syscolumns where id = OBJECT_ID('[dbo].[RSDSensorProperties]') AND (name='EPOLeafAutoId'))
BEGIN
	ALTER TABLE [dbo].[RSDSensorProperties]
		ADD [EpoLeafAutoId] Integer NOT NULL DEFAULT 0
END
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId]
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId]
AS
BEGIN
	Update [dbo].[RSDSensorProperties]
	SET [dbo].[RSDSensorProperties].[EpoLeafAutoId] = [dbo].[EPOLeafNodeMT].[AutoId]
	FROM [dbo].[RSDSensorProperties]
	JOIN [dbo].[EPOLeafNodeMT]
	ON [dbo].[RSDSensorProperties].[AgentGUID] = [dbo].[EPOLeafNodeMT].[AgentGUID];
	
	Delete
	From [dbo].[RSDSensorProperties]
	Where [dbo].[RSDSensorProperties].[EpoLeafAutoId] = 0;
	
END
GO

EXEC [dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateRSDSensorAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateRSDSensorAgentGUID]
GO

CREATE PROCEDURE [dbo].[RSDSP_UpdateRSDSensorAgentGUID]
(
    @InputAgentGUID				uniqueidentifier,
    @OutputEpoLeafAutoID		int OUTPUT,   
	@OutputNewSensor			bit OUTPUT
)
AS
BEGIN
	declare @ParentID int;
	declare @foundInRSD int;
	declare @NewSensor bit;

	set @foundInRSD = 0;	
	set @NewSensor = 1;
	
	select @ParentID = [dbo].[EPOLeafNode].[AutoID] 
	from [dbo].[EPOLeafNode]
	where @InputAgentGUID = [dbo].[EPOLeafNode].[AgentGUID];
		
	if(@ParentID is null or @ParentID = 0)
	begin										
		set @ParentID = 0;			
	end
	else
	begin
				
		select @foundInRSD = count(*)
		from [dbo].[RSDSensorProperties]
		where EpoLeafAutoId = @ParentID
			
		if(@foundInRSD > 0)
		begin	
			set @NewSensor = 0;
		
			update [dbo].[RSDSensorProperties]
			set AgentGUID = @InputAgentGUID
			where EpoLeafAutoId = @ParentID;
		end
	end 

	set @OutputEpoLeafAutoID = @ParentID;	
	set @OutputNewSensor = @NewSensor;
	
END
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensors]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDSensors]
GO

CREATE VIEW [dbo].[RSDSensors]
AS
SELECT  RSDSensorProperties.SensorID,
        RSDSensorProperties.SensorName,
        RSDSensorProperties.LastCommunicationTime,
        RSDSensorProperties.AgentGUID,
        RSDSensorProperties.SensorType,
        [dbo].[RSDFN_ManagedSystemSensorVersion](RSDSensorProperties.AgentGUID) as SensorVersion,
        RSDSensorProperties.Description,
        RSDSensorProperties.Started,
        RSDSensorProperties.ComputerName,
        RSDSensorProperties.FirstCommunicationTime,
        RSDSensorProperties.FirstRecordedTime,
        RSDSensorProperties.LastRecordedTime,
        RSDSensorProperties.LastStartedTime,
        RSDSensorProperties.LastStoppedTime,
        RSDSensorProperties.ElectionType,
        RSDSensorProperties.DHCP,
        [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, GETUTCDATE()) as Status,
        [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](RSDSensorProperties.AgentGUID) as Installed,
        RSDSensorProperties.AwakeStatus,
        RSDSensorProperties.StatusEventTime,
		RSDSensorProperties.EpoLeafAutoId
FROM    RSDSensorProperties
GO
