-------------------------------------------------------------------------------
-- Installation script for RSD tables in the ePO4 database.  This script is
-- called when the RSD extension is loaded/installed into a running ePO4
-- system.
--
-- Purpose: create all database artifacts required by the RSD extension.
-------------------------------------------------------------------------------

-- Make sure you call the "uninstall" first, to drop all tables and keys
CREATE TABLE [dbo].[RSDConfiguration](
	[ID] [int] NOT NULL,
	[APISchemaVersion] [int] NOT NULL,
	[RSDSchemaVersion] [int] NOT NULL,
	[Configuration] [nvarchar](3000) NULL,
	[LastAgentCommunication] [int] NOT NULL DEFAULT 20,
	[LastSensorDetection] [int] NOT NULL DEFAULT 45,
	[SensorTimeout] [int] NOT NULL DEFAULT 4320,
	[SensorsPerSubnet] [int] NOT NULL DEFAULT 2,
	[ActivePeriod] [int] NOT NULL DEFAULT 600,
	[DetectedMatching] [int] NOT NULL DEFAULT 0x33,
	[DetectedMerging] [int] NOT NULL DEFAULT 0x33,
	[ManagedMatching] [int] NOT NULL DEFAULT 0x31
) ON [PRIMARY]
GO

-- When you change the schema, increment the DBSchemaVersion property and update the RSDConfiguration java object
INSERT INTO [dbo].[RSDConfiguration] (ID, APISchemaVersion, RSDSchemaVersion)
VALUES (1, 29, 53)
GO

CREATE TABLE [dbo].[RSDConfigurationIPRanges](
	[ID] [int] NOT NULL,
	[StartAddress] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFF00000000,
	[EndAddress] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFFFFFFFFFF
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RSDDetectedSourceType] (
    [SourceType] [nvarchar] (100) UNIQUE NOT NULL,
    [SourceName] [nvarchar] (500) NOT NULL
) on [PRIMARY]
GO

INSERT INTO [dbo].[RSDDetectedSourceType] ( SourceType, SourceName )
VALUES ( 'McAfee', 'McAfee' )
GO

INSERT INTO [dbo].[RSDDetectedSourceType] ( SourceType, SourceName )
VALUES ( 'rsd.dhcp', 'Rogue System Sensor (DHCP)' )
GO

INSERT INTO [dbo].[RSDDetectedSourceType] ( SourceType, SourceName )
VALUES ( 'rsd.broadcast', 'Rogue System Sensor (Broadcast)' )
GO

INSERT INTO [dbo].[RSDDetectedSourceType] ( SourceType, SourceName )
VALUES ( 'rsd.unknown', 'Rogue System Sensor (Core)' )
GO

INSERT INTO [dbo].[RSDDetectedSourceType] ( SourceType, SourceName )
VALUES ( 'epo.agent', 'McAfee Agent' )
GO

-- We do NOT want to delete this table or add a new one every time, only update it...
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[OUIs]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
begin
CREATE TABLE [dbo].[OUIs] (
    [OUI]				nvarchar(6)	    UNIQUE NOT NULL,
    [OrgName]			nvarchar(255)	NOT NULL,	
) on [PRIMARY]

CREATE NONCLUSTERED INDEX [IX_OUIs_OUI] ON [dbo].[OUIs]
(
	[OUI]
) ON [PRIMARY]
end
GO

CREATE TABLE [dbo].[RSDVMVendorOUIs] (
    [OUI]       nvarchar(6) UNIQUE NOT NULL
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX[IX_RSDVMVendorOUIs_OUI] ON [dbo].[RSDVMVendorOUIs]
(
    [OUI]
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[RSDDetectedSystemProperties] (
	[HostID] [int] IDENTITY (1, 1) NOT NULL ,
	[DnsName] [nvarchar] (255) NULL ,
	[OSPlatform] [nvarchar] (25) NULL ,
	[OSFamily] [nvarchar] (128) NULL ,
	[OSVersion] [nvarchar] (128) NULL ,
	[Domain] [nvarchar] (16) NULL ,
	[NetbiosName] [nvarchar] (16) NULL ,
	[NetbiosComment] [nvarchar] (100) NULL ,
	[Users] [nvarchar] (128) NULL ,
	[AgentGUID] [uniqueidentifier] NULL ,
	[FriendlyName] [nvarchar] (255) NULL ,
	[Ignored] [bit] NOT NULL DEFAULT 0,
	[Comments] [nvarchar] (255) NULL ,
	[IPV4] [int] NULL DEFAULT -2147483648,
	[IPV6] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFF00000000,
	[MAC] [nvarchar] (12) NULL,
	[LastDetectedTime] [datetime] NULL,
	[DetectedSourceType] [nvarchar] (100) NULL,
	[Exception] [bit] NOT NULL DEFAULT 0,
	[RogueAction] [int] NOT NULL DEFAULT 0
) ON [PRIMARY]
GO

-- TODO: Decide which other columns should be indexed...
CREATE NONCLUSTERED INDEX [IX_RSDDetectedSystemProperties_AgentGUID] ON [dbo].[RSDDetectedSystemProperties]
(
	[AgentGUID] ASC
) ON [PRIMARY]
GO

CREATE FUNCTION [dbo].[RSDFN_IsManagedDetectedSystem]
(
    @HostID  int,
    @CompareDateTime datetime
)
RETURNS bit
AS
BEGIN
    declare @lastAgentComm int;
    select @lastAgentComm = LastAgentCommunication from RSDConfiguration where ID = 1

    declare @exception bit;
    declare @agentGUID uniqueidentifier;
    declare @lastAgentCommunication datetime;

    select @exception = Exception,
           @agentGUID = AgentGUID,
           @lastAgentCommunication = LastAgentCommunication
        from RSDDetectedSystems where HostID = @HostID;

    declare @ret bit;
    set @ret = 0;
    if (
        @exception = 0 and
        @agentGUID is not null and
        @lastAgentCommunication is not null and
        @lastAgentCommunication >= DATEADD(day, -1 * @lastAgentComm, @CompareDateTime)
        )
    begin
        set @ret = 1;
    end

    return @ret;
END
GO

CREATE FUNCTION [dbo].[RSDFN_IsRogueDetectedSystem]
(
    @HostID  int,
    @CompareDateTime datetime
)
RETURNS bit
AS
BEGIN
    declare @lastAgentComm int;
    declare @lastSensorDetect int;

    select @lastAgentComm = LastAgentCommunication, @lastSensorDetect = LastSensorDetection from RSDConfiguration where ID = 1

    declare @exception bit;
    declare @agentGUID uniqueidentifier;
    declare @rogueState int;
    declare @lastAgentCommunication datetime;
    declare @lastDetectedTime datetime;
    select @exception = Exception,
            @agentGUID = AgentGUID,
            @lastAgentCommunication = LastAgentCommunication,
            @lastDetectedTime = LastDetectedTime
        from RSDDetectedSystems where HostID = @HostID;

    set @rogueState = [dbo].[RSDFN_GetRogueState](@HostID, @CompareDateTime);

    declare @ret bit;
    set @ret = 0;
    if (
        @exception = 0 and
        (
            ( @agentGUID is null )
            or
            ( @rogueState = 1 )
            or
            ( @rogueState = 2 )
        )
        and
        (
            @lastDetectedTime >= DATEADD(day, -1 * @lastSensorDetect, @CompareDateTime)
        )
       )
    begin
        set @ret = 1;
    end

    return @ret;
END
GO

CREATE FUNCTION [dbo].[RSDFN_IsInactiveDetectedSystem]
(
    @HostID  int,
    @CompareDateTime datetime
)
RETURNS bit
AS
BEGIN
    declare @lastAgentComm int;
    declare @lastSensorDetect int;

    select @lastAgentComm = LastAgentCommunication, @lastSensorDetect = LastSensorDetection from RSDConfiguration where ID = 1

    declare @exception bit;
    declare @agentGUID uniqueidentifier;
    declare @rogueState int;
    declare @lastAgentCommunication datetime;
    declare @lastDetectedTime datetime;
    select @exception = Exception,
            @agentGUID = AgentGUID,
            @lastAgentCommunication = LastAgentCommunication,
            @lastDetectedTime = LastDetectedTime
        from RSDDetectedSystems where HostID = @HostID;

    set @rogueState = [dbo].[RSDFN_GetRogueState](@HostID, @CompareDateTime);

    declare @ret bit;
    set @ret = 0;
    if (
        @exception = 0 and
        (
            ( @agentGUID is null )
            or
            ( @rogueState = 1 )
            or
            ( @rogueState = 2 )
        )
        and
        (
            @lastDetectedTime < DATEADD(day, -1 * @lastSensorDetect, @CompareDateTime)
        )
       )
    begin
        set @ret = 1;
    end

    return @ret;
END
GO

CREATE FUNCTION [dbo].[RSDFN_GetRogueState]
(
    @HostID  int,
    @CompareDateTime datetime
)
RETURNS int
AS
BEGIN
    declare @AgentGUID uniqueidentifier;
    select @AgentGUID = AgentGUID from [dbo].[RSDDetectedSystemProperties] where HostID = @HostID;
    if (@AgentGUID is not null)
    begin
        declare @cnt int;
        select @cnt = count(*) from [dbo].[EPOLeafNode] where AgentGUID = @AgentGUID;
        if (@cnt = 0)
        begin
            -- This is an "Alien Agent"
            return 1;
        end
        else
        begin
            declare @lastAgentCommConfig int;
            select @lastAgentCommConfig = LastAgentCommunication from RSDConfiguration where ID = 1

            declare @LastAgentComm datetime;
            select @LastAgentComm = LastUpdate from [dbo].[EPOLeafNode] where AgentGUID = @AgentGUID;

            if (@LastAgentComm < DATEADD(day, -1 * @lastAgentCommConfig, @CompareDateTime))
            begin
                -- This is a "Dead Agent"
                return 2;
            end
            else
            begin
                -- This is a "managed" machine
                return -1;
            end
        end
    end

    return 0;
END
GO

CREATE FUNCTION [dbo].[RSDFN_GetOrganizationName]
(
    @MACorOUI  nvarchar(12)
)
RETURNS nvarchar (255)
AS
BEGIN
    declare @OUI nvarchar(6);
    declare @OrgName nvarchar(255);

    set @OUI = SUBSTRING(@MACorOUI, 1, 6);

    select @OrgName = OrgName from OUIs where OUI = @OUI;

    return @OrgName;
END
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT  RSDDetectedSystemProperties.HostID,
		RSDDetectedSystemProperties.DnsName,
		RSDDetectedSystemProperties.OSPlatform,
		RSDDetectedSystemProperties.OSFamily,
		RSDDetectedSystemProperties.OSVersion,
		RSDDetectedSystemProperties.Domain,
		RSDDetectedSystemProperties.NetbiosName,
		RSDDetectedSystemProperties.NetbiosComment,
		RSDDetectedSystemProperties.Users,
		RSDDetectedSystemProperties.AgentGUID,
		RSDDetectedSystemProperties.FriendlyName,
		RSDDetectedSystemProperties.Ignored,
		RSDDetectedSystemProperties.Comments,
		RSDDetectedSystemProperties.IPV4,
		RSDDetectedSystemProperties.IPV6,
		RSDDetectedSystemProperties.MAC,
		RSDDetectedSystemProperties.Exception,
		RSDDetectedSystemProperties.RogueAction,
        RSDDetectedSystemProperties.LastDetectedTime,
		[dbo].[RSDFN_GetOrganizationName](RSDDetectedSystemProperties.MAC) as OrgName,
        [dbo].[RSDFN_GetRogueState](RSDDetectedSystemProperties.HostID, GETUTCDATE()) as RogueState,
        [dbo].[RSDFN_IsManagedDetectedSystem](RSDDetectedSystemProperties.HostID, GETUTCDATE()) as Managed,
        [dbo].[RSDFN_IsRogueDetectedSystem](RSDDetectedSystemProperties.HostID, GETUTCDATE()) as Rogue,
        [dbo].[RSDFN_IsInactiveDetectedSystem](RSDDetectedSystemProperties.HostID, GETUTCDATE()) as Inactive,
		RSDDetectedSourceType.SourceName as DetectedSourceName,
		EPOLeafNode.LastUpdate as LastAgentCommunication,
        EPOLeafNode.AgentVersion as AgentVersion
FROM    RSDDetectedSystemProperties
		LEFT OUTER JOIN
        EPOLeafNode ON RSDDetectedSystemProperties.AgentGUID = EPOLeafNode.AgentGUID
		LEFT OUTER JOIN
		RSDDetectedSourceType ON RSDDetectedSystemProperties.DetectedSourceType = RSDDetectedSourceType.SourceType
WHERE   RSDDetectedSystemProperties.Ignored=0
GO


CREATE TABLE [dbo].[RSDInterfaceProperties] (
	[InterfaceID] [int] IDENTITY (1, 1) NOT NULL ,
	[HostID] [int] NOT NULL ,
	[MAC] [nvarchar] (12) NULL,
	[OUI] [nvarchar] (6) NULL  ,
    [IPV4] [int] NULL DEFAULT -2147483648,
    [IPV6] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFF00000000,
	[SubnetID] [int] NOT NULL,
	[LastDetectedTime] [datetime] NULL,
	[DetectedSourceType] [nvarchar] (100) NULL
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RSDInterfaceProperties_HostID] ON [dbo].[RSDInterfaceProperties]
(
	[HostID] ASC
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RSDInterfaceProperties_SubnetID] ON [dbo].[RSDInterfaceProperties]
(
	[SubnetID] ASC
) ON [PRIMARY]
GO

CREATE VIEW [dbo].[RSDInterfaces]
AS
SELECT  RSDInterfaceProperties.InterfaceID,
        RSDInterfaceProperties.HostID,
        RSDInterfaceProperties.MAC,
        RSDInterfaceProperties.OUI,
        RSDInterfaceProperties.IPV4,
        RSDInterfaceProperties.IPV6,
        RSDInterfaceProperties.SubnetID,
        RSDInterfaceProperties.LastDetectedTime,
        RSDDetectedSourceType.SourceName as DetectedSourceName,
        OUIs.OrgName
FROM    RSDInterfaceProperties
		LEFT OUTER JOIN
        OUIs ON RSDInterfaceProperties.OUI = OUIs.OUI
		LEFT OUTER JOIN
		RSDDetectedSourceType ON RSDInterfaceProperties.DetectedSourceType = RSDDetectedSourceType.SourceType
GO

CREATE TABLE [dbo].[RSDDetectedSource] (
    [AutoID] [int] IDENTITY (1, 1) NOT NULL,
    [HostID] [int] NOT NULL,
    [SourceID] [int] NOT NULL DEFAULT 0,
    [SourceType] [nvarchar] (100) NOT NULL DEFAULT N'McAfee',
    [ExternalID] [nvarchar] (1000) NULL,
    [FirstDetectedTime] [datetime] NOT NULL,
    [LastDetectedTime] [datetime] NOT NULL,
    [FirstRecordedTime] [datetime] NOT NULL,
    [LastRecordedTime] [datetime] NOT NULL
) on [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RSDDetectedSource_HostID] ON [dbo].[RSDDetectedSource]
(
	[HostID] ASC
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RSDSubnetProperties] (
	[SubnetID] [int] IDENTITY (1, 1) NOT NULL ,
	[SubnetName] [nvarchar] (255) NOT NULL ,
	[IPV4] [int] NULL DEFAULT -2147483648,
    [IPV4mask] [int] NULL DEFAULT 2147483647,
    [IPV6] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFF00000000,
	[IPV6mask] [binary] (16) NULL DEFAULT 0x00000000000000000000FFFFFFFFFFFF,
	[Ignored] [bit] NOT NULL DEFAULT 0,
	[PrevCoveredState] [bit] NOT NULL DEFAULT 0,
	[BitBucket] [bit] NOT NULL DEFAULT 0
) ON [PRIMARY]
GO

CREATE FUNCTION [dbo].[RSDFN_GetSensorStatus]
(
    @SensorID           int,
    @CompareDateTime    datetime
)
RETURNS int
AS
BEGIN
    -- 1 = active, 2 = passive, 3 = missing
    declare @ret int;
    declare @started bit;
    declare @lastCommunicationTime datetime;

    select @started = Started, @lastCommunicationTime = LastCommunicationTime from RSDSensorProperties where SensorID = @SensorID;

    if (@started = 1)
    begin
        declare @sensorTimeout int;
        select @sensorTimeout = SensorTimeout from RSDConfiguration where ID = 1;

        if ( @lastCommunicationTime < DATEADD(minute, -1 * @sensorTimeout, @CompareDateTime) )
        begin
            set @ret = 3;
        end
        else
        begin
            set @ret = 1;
        end
    end
    else
    begin
        set @ret = 2;
    end

    return @ret;
END
GO

CREATE FUNCTION [dbo].[RSDFN_IsSubnetCovered]
(
    @SubnetID           int,
    @CompareDateTime    datetime
)
RETURNS bit
AS
BEGIN
    declare @cnt int;
    select @cnt = count(*) from RSDSensorToSubnet where SubnetID = @SubnetID

    if (@cnt = 0)
        return 0;

    select @cnt = count(*) from RSDSensorProperties
    left join RSDSensorToSubnet on RSDSensorToSubnet.SensorID = RSDSensorProperties.SensorID
    where RSDSensorToSubnet.SubnetID = @SubnetID and [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, @CompareDateTime) = 1

    if (@cnt = 0) return 0;

    return 1;
END
GO

CREATE FUNCTION [dbo].[RSDFN_SubnetContainsRogueSystems]
(
    @SubnetID  int
)
RETURNS bit
AS
BEGIN
    declare @cnt int;

	select @cnt = count(*)
		from RSDInterfaceProperties
		inner join RSDSubnetProperties on RSDInterfaceProperties.SubnetID = RSDSubnetProperties.SubnetID
		inner join RSDDetectedSystems on RSDDetectedSystems.HostID = RSDInterfaceProperties.HostID
		where RSDSubnetProperties.Ignored = 0 and RSDDetectedSystems.Rogue = 1 and RSDSubnetProperties.SubnetID = @SubnetID

    if (@cnt = 0) return 0;

    return 1;
END
GO

CREATE VIEW [dbo].[RSDSubnets]
AS
    SELECT RSDSubnetProperties.SubnetID,
        RSDSubnetProperties.SubnetName,
        RSDSubnetProperties.IPV4,
        RSDSubnetProperties.IPV4mask,
        RSDSubnetProperties.IPV6,
        RSDSubnetProperties.IPV6mask,
        RSDSubnetProperties.Ignored,
        [dbo].[RSDFN_IsSubnetCovered](RSDSubnetProperties.SubnetID, GETUTCDATE()) as Covered,
        RSDSubnetProperties.PrevCoveredState,
        [dbo].[RSDFN_SubnetContainsRogueSystems](RSDSubnetProperties.SubnetID) as ContainsRogue
FROM RSDSubnetProperties
WHERE RSDSubnetProperties.BitBucket = 0
GO

INSERT INTO [dbo].[RSDSubnetProperties] (SubnetName, BitBucket)
VALUES (N'0.0.0.0/32', 1)
GO


CREATE TABLE [dbo].[RSDSensorToSubnet] (
	[SensorID] [int] NOT NULL ,
	[SubnetID] [int] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[RSDSensorProperties] (                   -- A lot of potentially duplicate information here
	[SensorID] [int] IDENTITY (1, 1) NOT NULL ,
	[SensorName] [nvarchar] (255) NOT NULL ,
	[LastCommunicationTime] [datetime] NOT NULL ,
	[AgentGUID] [uniqueidentifier] UNIQUE NOT NULL ,
	[SensorType] [int] NOT NULL DEFAULT 1,
	[SensorVersion] [nvarchar] (20) NOT NULL,
	[Started] [bit] NOT NULL DEFAULT 0,
	[Description] [nvarchar] (255) NULL,
	[Installed] [bit] NOT NULL DEFAULT 1
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RSDSensorProperties_AgentGUID] ON [dbo].[RSDSensorProperties]
(
	[AgentGUID] ASC
) ON [PRIMARY]
GO


CREATE FUNCTION [dbo].[RSDFN_ManagedSystemHasSensor]
(
    @ParentID  int
)
RETURNS bit
AS
BEGIN
    declare @hasSensor int;

	-- This will find out if there is a Sensor installed on this machine
	SELECT @hasSensor = count(*)
	FROM EPOProductProperties
	LEFT JOIN EPOProductFamilies ON EPOProductFamilies.ProductCode=EPOProductProperties.ProductCode
	LEFT JOIN EPOSoftware ON EPOSoftware.ProductCode=EPOProductProperties.ProductCode
	WHERE [EPOProductProperties].[ParentID]= @ParentID and EPOProductProperties.ProductCode = 'SNOWCAP_2000';

	if (@hasSensor <> 0)
		return 1;

	return 0;
END
GO

CREATE FUNCTION [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID]
(
    @AgentGUID      uniqueidentifier
)
RETURNS bit
AS
BEGIN
    declare @ParentID int;

    select @ParentID = AutoID from [dbo].[EPOLeafNode] where AgentGUID = @AgentGUID;

    return [dbo].[RSDFN_ManagedSystemHasSensor](@ParentID);
END
GO


CREATE VIEW [dbo].[RSDSensors]
AS
SELECT  RSDSensorProperties.SensorID,
        RSDSensorProperties.SensorName,
        RSDSensorProperties.LastCommunicationTime,
        RSDSensorProperties.AgentGUID,
        RSDSensorProperties.SensorType,
        RSDSensorProperties.SensorVersion,
        RSDSensorProperties.Description,
        RSDSensorProperties.Started,
        [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, GETUTCDATE()) as Status,
        [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](RSDSensorProperties.AgentGUID) as Installed
FROM    RSDSensorProperties
GO


CREATE TABLE [dbo].[RSDSensorBlacklistTarget] (
    [AgentGUID] [uniqueidentifier] UNIQUE NOT NULL
) ON [PRIMARY]
GO

CREATE INDEX [IX_RSDSensorBlacklistTarget_AgentGUID] ON [dbo].[RSDSensorBlacklistTarget]
(
    [AgentGUID]
) ON [PRIMARY]
GO


CREATE VIEW [dbo].[RSDSensorBlacklist]
AS
SELECT
        EPOComputerProperties.ParentID,
        EPOComputerProperties.ComputerName,
        EPOComputerProperties.DomainName as Domain,
        EPOComputerProperties.IPV4x as IPV4,
        EPOComputerProperties.IPHostName as DnsName,
        EPOComputerProperties.NetAddress as MAC,
        EPOLeafNode.AgentGUID
FROM    EPOComputerProperties
    JOIN EPOLeafNode ON EPOComputerProperties.ParentID = EPOLeafNode.AutoID
    JOIN RSDSensorBlacklistTarget ON EPOLeafNode.AgentGUID = RSDSensorBlacklistTarget.AgentGUID
GO


ALTER TABLE [dbo].[RSDConfiguration] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDConfiguration] PRIMARY KEY  CLUSTERED
	(
		[ID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDConfigurationIPRanges]  ADD
    CONSTRAINT [FK_RSDConfigurationIPRanges_RSDConfiguration] FOREIGN KEY
    (
        [ID]
    ) REFERENCES [dbo].[RSDConfiguration] (
        [ID]
    ) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RSDDetectedSystemProperties] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDDetectedSystemProperties] PRIMARY KEY  CLUSTERED
	(
		[HostID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDDetectedSource] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDDetectedSource] PRIMARY KEY  CLUSTERED
	(
		[AutoID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDInterfaceProperties] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDInterfaceProperties] PRIMARY KEY  CLUSTERED
	(
		[InterfaceID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDSubnetProperties] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDSubnetProperties] PRIMARY KEY  CLUSTERED
	(
		[SubnetID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDSensorToSubnet] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDSensorToSubnet] PRIMARY KEY  CLUSTERED
	(
		[SensorID],
		[SubnetID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDSensorProperties] WITH NOCHECK ADD
	CONSTRAINT [PK_RSDSensorProperties] PRIMARY KEY  CLUSTERED
	(
		[SensorID]
	)  ON [PRIMARY]
GO

ALTER TABLE [dbo].[RSDInterfaceProperties] ADD
	CONSTRAINT [FK_RSDInterfaceProperties_RSDDetectedSystemProperties] FOREIGN KEY
	(
		[HostID]
	) REFERENCES [dbo].[RSDDetectedSystemProperties] (
		[HostID]
	) ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RSDInterfaceProperties]  WITH CHECK ADD
    CONSTRAINT [FK_RSDInterfaceProperties_RSDSubnetProperties] FOREIGN KEY
    (
        [SubnetID]
    )
    REFERENCES [dbo].[RSDSubnetProperties]
    (
        [SubnetID]
    )
    ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RSDDetectedSource] ADD
	CONSTRAINT [FK_RSDDetectedSource_RSDDetectedSystemProperties] FOREIGN KEY
	(
		[HostID]
	) REFERENCES [dbo].[RSDDetectedSystemProperties] (
		[HostID]
	) ON DELETE CASCADE  
GO

ALTER TABLE [dbo].[RSDSensorToSubnet] ADD
	CONSTRAINT [FK_RSDSensorToSubnet_RSDSubnetProperties] FOREIGN KEY
	(
		[SubnetID]
	) REFERENCES [dbo].[RSDSubnetProperties] (
		[SubnetID]
	) ON DELETE CASCADE,
	CONSTRAINT [FK_RSDSensorToSubnet_RSDSensorProperties] FOREIGN KEY
	(
		[SensorID]
	) REFERENCES [dbo].[RSDSensorProperties] (
		[SensorID]
	) ON DELETE CASCADE
GO

