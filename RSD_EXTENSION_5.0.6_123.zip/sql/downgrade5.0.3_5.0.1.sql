ALTER PROCEDURE [dbo].[RSDSP_MatchManagedSystems]
(
	@HostID				int,
    @AgentGUID          uniqueidentifier,
    @MAC                nvarchar(12),
    @ComputerName       nvarchar(16),
    @Domain             nvarchar(255),
    @DnsName            nvarchar(255),
    @IPV4               int,
    @IPV6               binary (16),
    @DetectionType      nvarchar(255)
)
AS
BEGIN
    set nocount on;

    declare @managedMatching    int;
    declare @useAgentGUID       bit;
    declare @useProductGUID     bit;
    declare @useMAC             bit;
    declare @useHostnameDomain  bit;
    declare @useDNSName         bit;
    declare @useIPAddress       bit;
    declare @useHostname        bit;
    declare @found              bit;
    declare @cnt                int;
    declare @done               bit;
    declare @m_AgentGUID        uniqueidentifier;

    declare @results table
    (
        AgentGUID       uniqueidentifier,
        ComputerName    nvarchar(255),
        Domain          nvarchar(255),
        DnsName         nvarchar(255),
        IPV4            int,
        IPV6            binary (16)
    );

    -- The Configuration ID by default should always be 1
    select top 1 @managedMatching = [RSDConfiguration].[ManagedMatching]
        from [dbo].[RSDConfiguration];

    set @useAgentGUID = @managedMatching & 0x1;
    set @useProductGUID = @managedMatching & 0x2;
    set @useMAC = @managedMatching & 0x10;
    set @useHostnameDomain = @managedMatching & 0x20;
    set @useDNSName = @managedMatching & 0x40;
    set @useIPAddress = @managedMatching & 0x80;
    set @useHostname = @managedMatching & 0x100;

    set @found = 0;
	set @done = 0;
	set @cnt = 0;
    set @m_AgentGUID = null;

    -- squelch the domain name if it is an empty string
    if (@Domain = N'')
        set @Domain = NULL;

    -- same for computer name
    if (@ComputerName = N'')
        set @ComputerName = NULL;

    -- slurp the computer name from the full-DNS name if none was provided
    --  AND full-DNS matching is NOT a viable search option.
    if (@ComputerName is null and @DnsName is not null and @DnsName <> N'' and @useDNSName = 0)
    begin
        DECLARE @dot int;
        SET @dot = CHARINDEX(N'.', @DnsName);
        if (@dot > 0)
            set @ComputerName = SUBSTRING(@DnsName, 0, @dot);
        else
            set @ComputerName = @DnsName; -- no dots. use full name
    end

    -- match on AgentGUID first
    if (@AgentGUID is not null and @useAgentGUID = 1)
    begin
        select top 1 @m_AgentGUID = AgentGUID
        from EPOLeafNode ln inner join EPOComputerProperties cp
            on (ln.AutoID = cp.ParentID)
        where (ln.AgentGUID = @AgentGUID)
        and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
            or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

		-- non-null AgentGUID is unique in EPOLeafNode, so confidence is high.
        if (@m_AgentGUID is not null)
            set @done = 1;
    end

    -- match on MAC address
	if (@done = 0
	    and @useMAC = 1
	    and @MAC is not null
	    and (LEN(@MAC) > 0)
	    and not exists(
            select 1 from 
            (   -- sub-select-union for ganging RSD and EPO virtual OUIs
                select OUI from RSDVMVendorOUIs union
                select VendorID OUI FROM EPOVirtualMacVendor
            ) OUIs
            where substring(@MAC, 0, len(OUIs.OUI)+1) = OUIs.OUI))
	begin
	    -- build list from matching MAC address(es)
		insert into @results (AgentGUID, ComputerName, Domain, DnsName, IPV4, IPV6)
			select ln.[AgentGUID],
				   cp.[ComputerName],
				   cp.[DomainName],
				   cp.[IPHostName],
				   [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]),
				   cp.[IPV6]
			from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
				on ln.[AutoID] = cp.[ParentID]
			where (cp.[NetAddress] = @MAC)
			and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
               or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

        -- retrieve result count.
        --  * more than zero indicates matches
        --  * exactly one indicates completion (exact match)
		select @cnt = count(*) from @results;
		if (@cnt > 0)
		begin
			set @found = 1;
		    if (@cnt = 1)
		    begin
			    set @done = 1;
			    select top 1 @m_AgentGUID = AgentGUID from @results;
		    end
		end
	end

    -- match on domain\hostname
	if (@done = 0 and @ComputerName is not null and @useHostnameDomain = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (AgentGUID, ComputerName, DnsName, IPV4, IPV6)
				select
				    ln.[AgentGUID],
				    cp.[ComputerName],
				    cp.[IPHostName],
				    [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]),
				    cp.[IPV6]
				from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where ((cp.[ComputerName] = @ComputerName) and (cp.[DomainName] = @Domain))
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

            -- retrieve result count.
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
				set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select top 1 @m_AgentGUID = AgentGUID from @results;
			    end
			end
		end
		else
		begin
		    -- already have previous results (multiple matches on same mac)
		    --  filter down based on domain\system name
			delete from @results
			where (ComputerName <> @ComputerName) or (Domain <> @Domain);

            -- unlike RSDSP_MatchDetectedSystems, we don't keep the most-recent
            --  insertion from EPOLeafNode as the match. things must be exact.
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select top 1 @m_AgentGUID = AgentGUID from @results;
			    end
			end
			else
			begin
			    -- not searching any further. no match
			    set @done = 1
			end
		end
	end

    -- match on DNS
	if (@done = 0 and @DnsName is not null and @useDNSName = 1)
	begin
		if (@found = 0)
		begin
		    -- look for matches on the DNS name
			insert into @results (AgentGUID, ComputerName, IPV4, IPV6)
				select ln.[AgentGUID],
					   cp.[ComputerName],
    				   [dbo].[RSDFN_ConvertIPV6BinaryToInt](cp.[IPV6]),
					   cp.[IPV6]
				from [EPOLeafNode] ln inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where (cp.[IPHostName] = @DnsName)
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

            -- retrieve result count.
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
				set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select @m_AgentGUID = AgentGUID from @results;
			    end
			end
		end
		else
		begin
		    -- filter out all systems with no matching DNS name
			delete from @results
			where (DnsName <> @DnsName);

            -- retrieve result count.
            --  * more than zero indicates matches
            --  * exactly one indicates completion (exact match)
			select @cnt = count(*) from @results;
			if (@cnt > 0)
			begin
			    set @found = 1;
			    if (@cnt = 1)
			    begin
				    set @done = 1;
				    select @m_AgentGUID = AgentGUID from @results;
				end
			end
			else
			begin
			    -- not searching any further. no match
			    set @done = 1;
			end
		end
	end

	-- check on either IPv4 or IPv6 (these really need to be separate)
	if (@done = 0 and ( @IPV4 is not null or @IPV6 is not null) and @useIPAddress = 1)
	begin
		-- convert IPV4 to IPV6 so we can just use a single algorithm :)
		declare @ipaddr binary(16);
		if (@IPV4 is not null)
		begin
			set @ipaddr = [dbo].[RSDFN_ConvertIntToIPV6Binary](@IPV4);
			if (@ipaddr is null or DATALENGTH(@ipaddr) = 0)
			    set @ipaddr = @IPV6
		end
		else
		begin
			set @ipaddr = @IPV6;
		end

		-- We only want to do anything if this IPAddress falls in the correct range
		if (@ipaddr is not null and [dbo].[RSDFN_IsInRSDConfigurationIPRange](@ipaddr) = 1)
		begin
			if (@found = 0)
			begin
    			insert into @results (AgentGUID, ComputerName)
					select ln.[AgentGUID],
						   cp.[ComputerName]
				    from [EPOLeafNode] ln
					    inner join [EPOComputerProperties] cp
					    on ln.[AutoID] = cp.[ParentID]
					    where cp.[IPV6] = @ipaddr
                        and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                           or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));

                -- retrieve result count.
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
				select @cnt = count(*) from @results;
				if (@cnt > 0)
				begin
					set @found = 1;
				    if (@cnt = 1)
				    begin
					    set @done = 1;
					    select @m_AgentGUID = AgentGUID from @results;
				    end
				end
			end
			else
			begin
				-- If this is IPV4, remove the IPV4 elements...
				if (@IPV4 is not null)
				begin
					delete from @results where (IPV4 <> @IPV4);
				end
				else
				begin
					delete from @results where (IPV6 <> @IPV6);
				end

                -- retrieve result count.
                --  * more than zero indicates matches
                --  * exactly one indicates completion (exact match)
    			select @cnt = count(*) from @results;
				if (@cnt > 0)
				begin
					set @found = 1;
				    if (@cnt = 1)
				    begin
					    set @done = 1;
					    select @m_AgentGUID = AgentGUID from @results;
				    end
				end
				else
				begin
			        -- not searching any further. no match
					set @done = 1;
				end
			end
		end
	end

	-- match on hostname only
	if (@done = 0 and @ComputerName is not null and @useHostname = 1)
	begin
		if (@found = 0)
		begin
			insert into @results (AgentGUID)
				select ln.[AgentGUID]
				from [EPOLeafNode] ln
					inner join [EPOComputerProperties] cp
					on ln.[AutoID] = cp.[ParentID]
				where (cp.[ComputerName] = @ComputerName)
                and (((@DetectionType is null or @DetectionType = N'detectedSystem') and cp.[ManagementType] is null)
                   or (@DetectionType is not null and cp.[ManagementType] = @DetectionType));
		end
		else
		begin
		    -- filter results on hostname from prior selection
			delete from @results
			where (ComputerName <> @ComputerName);
		end

        -- retrieve result count.
        --  * more than zero indicates matches
        --  * exactly one indicates completion (exact match)
		select @cnt = count(*) from @results;
	    if (@cnt = 1)
	    begin
		    set @done = 1;
		    select @m_AgentGUID = AgentGUID from @results;
	    end
	end

    -- after all of that, we only reduce an update if there is only one
    -- possible match that made it through the above conditionals.
	if (@done = 1 and @m_AgentGUID is not null)
	begin
		update [dbo].[RSDDetectedSystemProperties]
		set AgentGUID = @m_AgentGUID, RogueAction = 0
		where HostID = @HostID
		and (AgentGUID is null OR AgentGUID <> @m_AgentGUID OR RogueAction is null OR RogueAction <> 0);
	end
END
GO