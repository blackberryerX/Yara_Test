-- Removing fix as part of downgradfe for Bug 1156027 - Sensor Version is not removed when product is Uninstalled.

EXEC EPOCore_DropFunction N'RSDFN_ManagedSystemSensorVersion';
GO

if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDSensors]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[RSDSensors]
GO

CREATE VIEW [dbo].[RSDSensors]
AS
SELECT  RSDSensorProperties.SensorID,
        RSDSensorProperties.SensorName,
        RSDSensorProperties.LastCommunicationTime,
        RSDSensorProperties.AgentGUID,
        RSDSensorProperties.SensorType,
        RSDSensorProperties.SensorVersion,
        RSDSensorProperties.Description,
        RSDSensorProperties.Started,
        RSDSensorProperties.ComputerName,
        RSDSensorProperties.FirstCommunicationTime,
        RSDSensorProperties.FirstRecordedTime,
        RSDSensorProperties.LastRecordedTime,
        RSDSensorProperties.LastStartedTime,
        RSDSensorProperties.LastStoppedTime,
        RSDSensorProperties.ElectionType,
        RSDSensorProperties.DHCP,
        [dbo].[RSDFN_GetSensorStatus](RSDSensorProperties.SensorID, GETUTCDATE()) as Status,
        [dbo].[RSDFN_ManagedSystemHasSensorByAgentGUID](RSDSensorProperties.AgentGUID) as Installed,
        RSDSensorProperties.AwakeStatus,
        RSDSensorProperties.StatusEventTime

FROM    RSDSensorProperties
GO

-- END RSDDetectedSystems

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateRSDSensorAgentGUID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateRSDSensorAgentGUID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RSDSP_UpdateRSDSensorPropertiesEpoLeafAutoId]
GO

IF EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorProperties]') AND [name] = 'EpoLeafAutoId')
BEGIN
    ALTER TABLE [dbo].[RSDSensorProperties] 
	DROP COLUMN EpoLeafAutoId;
END
GO


