-------------------------------------------------------------------------------
-- Uninstall script for RSD tables in the ePO4 database.  This script is
-- called when the RSD extension is unloaded/deinstalled from a running ePO4
-- system.
--
-- Purpose: delete all database artifacts related to the RSD extension.
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
--  Uninstall 4.7.0 information
-------------------------------------------------------------------------------
-- Drop Stored Procs
EXEC EPOCore_DropStoredProc N'RSDSP_GetOrionEvents';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddOrionEvent';
GO

EXEC EPOCore_DropStoredProc N'EPORSD_MigratePoliciesToMeta';
GO

EXEC EPOCore_DropStoredProc N'EPORSD_SaveTaskSettingsFor47Migration';
GO

EXEC EPOCore_DropStoredProc N'EPORSD_Add47MigratedTaskAssignment';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddMoveToTreeCriteria';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_DeleteTreeCriteria';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_Bulk_MatchDetectedSystems';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_Bulk_MatchManagedSystems';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_Bulk_MatchNewDetectedSystems';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_Bulk_UpdateDetectedSystems';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_Bulk_UpdateNewDetectedSystems';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_BulkUpdate';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_ForceNewPolicyNextUpdate';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_UpdateNewDetectedSystemEventCheck';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddDetectedSystemToEPOSystemTreeAndSort';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_AddOrUpdateDetectedSourceType';
GO

EXEC EPOCore_DropStoredProc N'RSDSP_DeletedDetectedSourceType';
GO

-- Drop Functions
EXEC EPOCore_DropFunction N'RSDFN_CreateMatchingComputerNameToUse';
GO

EXEC EPOCore_DropFunction N'RSDFN_MatchAddToTreeCriteria';
GO

EXEC EPOCore_DropFunction N'RSDFN_FindSensorNameForHostID';
GO

EXEC EPOCore_DropFunction N'RSDFN_Ipv6SubnetAddrEnd';
GO

EXEC EPOCore_DropFunction N'RSDFN_Ipv6SubnetAddrStart';
GO

EXEC EPOCore_DropFunction N'RSDFN_IsValidIPV6AddressAndMask';
GO

EXEC EPOCore_DropFunction N'RSDFN_IsValidIPV6Mask';
GO

EXEC EPOCore_DropFunction N'RSDFN_SystemAlreadyHasSensorDeploymentClientTask';
GO

EXEC EPOCore_DropFunction N'RSDFN_ValidateMACString';
GO

EXEC EPOCore_DropFunction N'RSDFN_GetLastDetectedSourceId';
GO

-- Drop Views
if exists (select * from .[dbo].sysobjects where id = object_id(N'.[dbo].[RSDDetectionSources]') and OBJECTPROPERTY(id, N'IsView') = 1)
  DROP VIEW [dbo].[RSDDetectionSources]
GO

-- Drop Tables
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSD47MigrateTaskAssignments]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[RSD47MigrateTaskAssignments]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDOrionEvents]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[RSDOrionEvents]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSD47MigrateTaskObjectSettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[RSD47MigrateTaskObjectSettings]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSD47MigrateTaskObjectSettings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[RSD47MigrateTaskObjectSettings]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDScanBlacklist]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  drop table [dbo].[RSDScanBlacklist]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[RSDMoveToTreeMatchingCriteria]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
  DROP TABLE [dbo].[RSDMoveToTreeMatchingCriteria]
GO
