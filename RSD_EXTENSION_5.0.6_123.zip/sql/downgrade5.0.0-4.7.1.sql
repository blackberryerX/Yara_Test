IF EXISTS (select * from [dbo].[RSDDetectedSourceType] where SourceType = 'mam.broadcast')
BEGIN
    delete from [dbo].[RSDDetectedSourceType] where SourceType = 'mam.broadcast'
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MAMFN_GetLastReportingSensor]') )
    DROP FUNCTION [dbo].[MAMFN_GetLastReportingSensor]
GO

IF EXISTS (SELECT * FROM .[dbo].sysobjects WHERE id = object_id(N'.[dbo].[RSDDetectedSystems]') and OBJECTPROPERTY(id, N'IsView') = 1)
    drop view [dbo].[RSDDetectedSystems]
GO

CREATE VIEW [dbo].[RSDDetectedSystems]
AS
SELECT
	dsp.HostID,
	dsp.DnsName,
	dsp.OSPlatform,
	dsp.OSFamily,
	dsp.OSVersion,
	dsp.Domain,
	dsp.NetbiosName,
	dsp.NetbiosComment,
	dsp.Users,
	dsp.AgentGUID,
	dsp.FriendlyName,
	dsp.Ignored,
	dsp.Comments,
	dsp.IPV4,
	dsp.IPV6,
	dsp.MAC,
	dsp.Exception,
	dsp.RogueAction,
	dsp.LastDetectedTime,
	dsp.RecordedTime,
	dsp.NewDetection,
	dsp.DeviceType,
	[dbo].[RSDFN_GetLastDetectedSourceId](dsp.HostId) As SourceID,
	o.OUI,
	o.OrgName,
	CASE
		WHEN dsp.AgentGUID IS NULL THEN 0
		WHEN ISNULL(ac.AgentCount, 0) = 0 THEN 1	-- This is an "Alien Agent"
		WHEN n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 2	-- This is a "Dead Agent"
		WHEN n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN -1	-- This is a "Managed" machine
		ELSE 0
	END	AS RogueState,
	CAST
	( CASE
		WHEN dsp.Exception = 0
			AND	dsp.AgentGUID IS NOT NULL
			AND	n.LastUpdate IS NOT NULL
			AND	n.LastUpdate >= DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE()) THEN 1
		WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
				) is not null
			) THEN 1
		ELSE 0
	END AS BIT ) AS Managed,
	CAST
	( CASE
        WHEN (
				(select ServerName 
					from [dbo].[RSDDetectedSystemAgentProperties] DSAP
					where HostID = dsp.HostID 
						and ((select ServerName from RSDConfigurationAlternateEpoServers AES
								WHERE (dbo.[RSDFN_IsInDelimitedList](AES.ServerName, DSAP.ServerName,';') = 1))
							is not null)
			  ) is not null
			) THEN 0
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime >= DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN	1
		ELSE	0
	END AS BIT ) AS Rogue,
	CAST
	( CASE
		WHEN
		(	dsp.AgentGUID IS NULL
			OR	ISNULL(ac.AgentCount, 0) = 0
			OR	n.LastUpdate < DATEADD(day, -1 * c.LastAgentCommunication, GETUTCDATE())
		)
		AND dsp.Exception = 0
		AND	dsp.LastDetectedTime < DATEADD(day, -1 * c.LastSensorDetection, GETUTCDATE())
		THEN 1
		ELSE 0
	END	AS BIT ) AS Inactive,
	dst.SourceName AS DetectedSourceName,
	n.LastUpdate AS LastAgentCommunication,
	n.AgentVersion AS AgentVersion,
	CASE
		WHEN n.AutoID IS not null THEN (select top 1 ComputerName from [dbo].[EPOServerInfo])
		ELSE (select ServerName from [dbo].[RSDDetectedSystemAgentProperties] where HostID = dsp.HostID)
	END AS ServerName,
	(select [Name] from [dbo].[RSDExceptionCategories] where CategoryID = dsp.ExceptionCategoryID)
	AS ExceptionCategory

FROM
(
	dbo.RSDDetectedSystemProperties	dsp
	LEFT OUTER JOIN	dbo.EPOLeafNode n ON dsp.AgentGUID = n.AgentGUID
	LEFT OUTER JOIN	dbo.RSDDetectedSourceType dst ON dsp.DetectedSourceType	= dst.SourceType
	LEFT OUTER JOIN	dbo.OUIs o ON SUBSTRING(dsp.MAC, 1, 6) = o.OUI AND dsp.MAC IS NOT NULL
	LEFT OUTER JOIN
	(
		SELECT AgentGUID, COUNT(*) AS AgentCount FROM dbo.EPOLeafNode WHERE AgentGUID IS NOT NULL GROUP BY AgentGUID
	) ac ON dsp.AgentGUID = ac.AgentGUID
)
CROSS JOIN
(
	SELECT * FROM dbo.RSDConfiguration WHERE ID = 1
) c
WHERE dsp.Ignored=0;
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDLookupOSName]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    drop table [dbo].[RSDLookupOSName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_LookupMAMOSInfo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_LookupMAMOSInfo]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSDSP_UpdateDetectedSystems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RSDSP_UpdateDetectedSystems]
GO
CREATE PROCEDURE [dbo].[RSDSP_UpdateDetectedSystems]
(
    @DnsName					nvarchar(255),
    @OSPlatform					nvarchar(25),
    @OSFamily					nvarchar(128),
    @OSVersion					nvarchar(128),
    @Domain						nvarchar(255),
    @NetbiosName				nvarchar(16),
    @NetbiosComment				nvarchar(100),
    @Users						nvarchar(128),
    @AgentGUID					uniqueidentifier,
    @IPV4						int,
    @IPV6						varbinary (16),
    @MAC						nvarchar(12),
    @DetectedTime				datetime,
    @DeviceType					nvarchar(100),
    @SourceID					int,
    @SourceType					nvarchar(100),
    @ExternalID					nvarchar(1000),
    @DetectionType              nvarchar(255),
    @ExternalFriendlyName		nvarchar(255),
    @MatchingOverride       	int,
    @OutputHostID				int OUTPUT,
    @OutputNewDetection			bit OUTPUT
)
AS
BEGIN
    declare @NewDetection bit;
    set @NewDetection = 0;

    declare @FriendlyName nvarchar(255);
    declare @HostID int;

    if (@MAC is not null)
    begin
        set @MAC = UPPER(@MAC);

		-- bug 431315 - if MAC is from a VPN or other "exclude this" list, then don't use it (set to null)
		declare @OUI nvarchar(6);
		set @OUI = SUBSTRING(@MAC, 0, 7);

		declare @vendorIdCount int;
		select @vendorIdCount = count(*) from EPOVirtualMacVendor where VendorID = @OUI;
		if (@vendorIdCount > 0)
		begin
			set @MAC = NULL;
		end
    end;

    if (DATALENGTH(@IPV6) = 4)
    begin
        set @IPV6 = 0x00000000000000000000FFFF + @IPV6;
    end

    -- Begin fix for 457424 / 457673
	-- If the interface is in an ignored subnet, do not add the interface
	-- and make sure we don't end up orphaning a detected system object
    declare @OutSubnetID int;
    if (@IPV6 is not null)
    begin
        exec RSDSP_FindSubnetForIPAddress @IPV6, @OutSubnetID output
    end
	-- If the subnetid is not null and the associated subnet is "ignored", then we don't want to continue
    if (@OutSubnetID is not null and exists(select 1 from RSDSubnetProperties where SubnetID = @OutSubnetID and Ignored = 1))
	begin
		-- We're going to bail out of here now
		set @OutputHostID = 0;
		set @OutputNewDetection = 0;
		return;
	end
	-- End fix for 457424 / 457673

	-- Match detected systems
	exec RSDSP_MatchDetectedSystems @AgentGUID, @SourceID, @SourceType, @ExternalID,
		@MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @DetectionType,
		@MatchingOverride, @HostID output;

    -- Keep track of when this item was recorded
    declare @RecordedTime datetime;
    set @RecordedTime = GETUTCDATE();

    -- If this identity algoritm returns a match, then update the DetectedSystem,
    -- Interfaces, DetectedSource, and Status with the new data
    if (@HostID is not null)
    begin
        -- We need to get the existing data and replace all non-null values with updated data
        declare @_DnsName            nvarchar(255);
        declare @_OSPlatform         nvarchar(25);
        declare @_OSFamily           nvarchar(128);
        declare @_OSVersion          nvarchar(128);
        declare @_Domain             nvarchar(255);
        declare @_NetbiosName        nvarchar(16);
        declare @_NetbiosComment     nvarchar(100);
        declare @_Users              nvarchar(128);
        declare @_AgentGUID          uniqueidentifier;
        declare @_IPV4               int;
        declare @_IPV6               varbinary (16);
        declare @_MAC                nvarchar(12);
        declare @_DetectedTime       datetime;
        declare @_DeviceType         nvarchar(100);
        declare @_SourceType         nvarchar(100);

        select TOP 1 @_DnsName = DnsName,
               @_OSPlatform = OSPlatform,
               @_OSFamily = OSFamily,
               @_OSVersion = OSVersion,
               @_Domain = [Domain],
               @_NetbiosName = NetbiosName,
               @_NetbiosComment = NetbiosComment,
               @_Users = Users,
               @_AgentGUID = AgentGUID,
               @_IPV4 = IPV4,
               @_IPV6 = IPV6,
               @_MAC = MAC,
               @_DetectedTime = LastDetectedTime,
               @_DeviceType = DeviceType,
               @_SourceType = DetectedSourceType
        from [dbo].[RSDDetectedSystemProperties]
        where HostID = @HostID;

		if (@DnsName is null or LEN(@DnsName) = 0)
			set @DnsName = @_DnsName;

		if ((@OSPlatform is null or LEN(@OSPlatform) = 0) or (@OSPlatform = N'Unknown' and @_OSPlatform <> N'Unknown'))
		    set @OSPlatform = @_OSPlatform;

		if (@OSFamily is null or LEN(@OSFamily) = 0)
			set @OSFamily = @_OSFamily;

		if (@OSVersion is null or LEN(@OSVersion) = 0)
			set @OSVersion = @_OSVersion;

		if (@Domain is null or LEN(@Domain) = 0)
			set @Domain = @_Domain;

		if (@NetbiosName is null or LEN(@NetbiosName) = 0)
			set @NetbiosName = @_NetbiosName;

		if (@NetbiosComment is null or LEN(@NetbiosComment) = 0)
			set @NetbiosComment = @_NetbiosComment;

		if (@Users is null or LEN(@Users) = 0)
			set @Users = @_Users;

        set @AgentGUID = ISNULL(@AgentGUID, @_AgentGUID);

        if (@IPV4 = -2147483648 or @IPV4 is null)
            set @IPV4 = @_IPV4;

        set @IPV6 = ISNULL(@IPV6, @_IPV6);

		if (@MAC is null or LEN(@MAC) = 0)
			set @MAC = @_MAC;

        set @DetectedTime = ISNULL(@DetectedTime, @_DetectedTime);

		if (@DeviceType is null or LEN(@DeviceType) = 0)
			set @DeviceType = @_DeviceType;

		if (@ExternalFriendlyName is null or LEN(@ExternalFriendlyName) = 0)
			set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);
		else
			set @FriendlyName = @ExternalFriendlyName

        update [dbo].[RSDDetectedSystemProperties]
        set DnsName = @DnsName,
            OSPlatform = @OSPlatform,
            OSFamily = @OSFamily,
            OSVersion = @OSVersion,
            [Domain] = @Domain,
            NetbiosName = @NetbiosName,
            NetbiosComment = @NetbiosComment,
            Users = @Users,
            AgentGUID = @AgentGUID,
            IPV4 = @IPV4,
            IPV6 = @IPV6,
            MAC = @MAC,
            LastDetectedTime = @DetectedTime,
            FriendlyName = @FriendlyName,
            DetectedSourceType = @SourceType,
            RecordedTime = @RecordedTime,
            DeviceType = @DeviceType,
            NewDetection = 0,
            DetectionType = @DetectionType,
            ExternalFriendlyName = @ExternalFriendlyName,
            MatchingOverride = @MatchingOverride
        where HostID = @HostID;
    end
    else
    begin
        -- Friendly name is determined by the following, whichever one is not null
		set nocount on;

		if (@ExternalFriendlyName is null or LEN(@ExternalFriendlyName) = 0)
			set @FriendlyName = [dbo].[RSDFN_CreateCanonicalName](@DnsName, @NetbiosName, @IPV6, @IPV4, @MAC);
		else
			set @FriendlyName = @ExternalFriendlyName

        -- Otherwise, add a new row to the DetectedSystems, Interfaces, Status,
        -- DetectedSource and if the RDSSubnets doesn't have associated subnets
        -- we'll need to add in subnet tables, too...
        insert into [dbo].[RSDDetectedSystemProperties] (DnsName, OSPlatform, OSFamily, OSVersion, [Domain],
            NetbiosName, NetbiosComment, Users, AgentGUID, FriendlyName, IPV4, IPV6, MAC,
            LastDetectedTime, DetectedSourceType, Ignored, RecordedTime, DeviceType, NewDetection,
            DetectionType, ExternalFriendlyName, MatchingOverride)
        values (@DnsName, @OSPlatform, @OSFamily, @OSVersion, @Domain,
            @NetbiosName, @NetbiosComment, @Users, @AgentGUID, @FriendlyName, @IPV4, @IPV6, @MAC,
            @DetectedTime, @SourceType, 0, @RecordedTime, @DeviceType, 1, @DetectionType,
            @ExternalFriendlyName, @MatchingOverride);
        select @HostID = SCOPE_IDENTITY();

        set @NewDetection = 1;
    end

	-- Updates the Detected System with the matching ManagedSystem, if it exists...
	 exec RSDSP_MatchManagedSystems @HostID, @AgentGUID, @MAC, @NetbiosName, @Domain, @DnsName, @IPV4, @IPV6, @DetectionType

	-- if the external id is provided, use it as further qualification when performing
	--  the detected source update. otherwise use the base info.
	if (@HostID IS NOT NULL)
	begin
		declare @dsid int;
		if (@ExternalID is not null)
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType)
				and (ExternalID = @ExternalID);
		end
		else
		begin
			select @dsid = AutoID from RSDDetectedSource
				where (HostID = @HostID)
				and (SourceID = @SourceID)
				and (SourceType = @SourceType);
		end

		-- update source record timestamps
		if (@dsid is not null)
		begin
			update RSDDetectedSource
				set LastDetectedTime = @DetectedTime, LastRecordedTime = @RecordedTime
				where AutoID = @dsid;
		end
		else
		begin
			-- add  detected source record, which couldn't have existed prior because there was no hostid.
			insert into RSDDetectedSource (HostID, SourceID, SourceType, ExternalID, FirstDetectedTime, LastDetectedTime, FirstRecordedTime, LastRecordedTime)
			values (@HostID, @SourceID, @SourceType, @ExternalID, @DetectedTime, @DetectedTime, @RecordedTime, @RecordedTime);
		end
	end

    -- Gonna need a second stored procedure for the interfaces and subnets, so return the HostID for the
    -- next round of inserts
	set @OutputHostID = @HostID;
    set @OutputNewDetection = @NewDetection;
END
GO

IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDScanBlacklistIp]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE [dbo].[RSDScanBlacklistIp]
GO

IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDSequences]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE [dbo].[RSDSequences]
GO

IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = object_id(N'[dbo].[RSDSP_NextVal]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    DROP PROCEDURE [dbo].[RSDSP_NextVal]  
GO  

IF EXISTS (SELECT * FROM [dbo].[syscolumns] WHERE id = OBJECT_ID(N'[dbo].[RSDConfiguration]') AND [name] = 'electionPhrase')
BEGIN
    ALTER TABLE [dbo].[RSDConfiguration] DROP COLUMN electionPhrase;
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'[dbo].[MAMSP_GetRSDSensorKey]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[MAMSP_GetRSDSensorKey]
GO

IF EXISTS (SELECT * FROM [dbo].[sysobjects] WHERE id = OBJECT_ID(N'[dbo].[RSDSensorKeys]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE [dbo].[RSDSensorKeys]
GO

IF  EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDInterfaceProperties]') 
    AND name = N'IX_RSDInterfaceProperties_MAC_HostIDIPAddr')
BEGIN
   DROP INDEX [dbo].[RSDInterfaceProperties].[IX_RSDInterfaceProperties_MAC_HostIDIPAddr];
END
GO

IF  EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSystemProperties]') 
    AND name = N'IX_RSDDetectedSystemProperties_DomainNetbiosName')
BEGIN
   DROP INDEX [dbo].[RSDDetectedSystemProperties].[IX_RSDDetectedSystemProperties_DomainNetbiosName];
END
GO

IF  EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[RSDDetectedSource]') 
    AND name = N'IX_RSDDetectedSource_SourceType_HostIDExternalID')
BEGIN
   DROP INDEX [dbo].[RSDDetectedSource].[IX_RSDDetectedSource_SourceType_HostIDExternalID];
END
GO

