#!/bin/bash

#Define MGMT Console URL
URL="https://usea1-s1university.sentinelone.net"

#Cleanup Cronjobs
crontab -r

response=$(curl -s -H "Content-Type: application/json" --request GET http://10.0.0.254/skytap) > /dev/null 2>&1

USER_DATA=$(echo $response | jq .configuration_user_data | tr -d '"')

IFS='|' read -ra DATA <<< "$USER_DATA"

WORD=$(echo ${DATA[0]})
SITE_TOKEN=$(echo ${DATA[1]})
USER_EMAIL=$(echo ${DATA[2]})
PASSWORD=$(echo ${DATA[3]})

while [ "$WORD" != "SiteToken" ]; do

  sleep 10
  
  response=$(curl -s -H "Content-Type: application/json" --request GET http://10.0.0.254/skytap) > /dev/null 2>&1

  USER_DATA=$(echo $response | jq .configuration_user_data | tr -d '"')

  IFS='|' read -ra DATA <<< "$USER_DATA"

  WORD=$(echo ${DATA[0]})
  SITE_TOKEN=$(echo ${DATA[1]})
  USER_EMAIL=$(echo ${DATA[2]})
  PASSWORD=$(echo ${DATA[3]})

done

#hostnamectl set-hostname $NAME

#Disable default 2FA
#response=$(curl -s -H "Content-Type: application/json" -H "Authorization: ApiToken ${API_KEY}" --request PUT https://usea1-s1university.sentinelone.net/web/api/v2.1/system/configuration -d "{\"filter\":{\"siteIds\":\"${ID}\"},\"data\":{\"globalTwoFaEnabled\":\"false\"}}") > /dev/null 2>&1

echo "Visit the URL below and authenticate with the Logon Email and Password to complete the Lab. Must setup 2FA at first logon." > /home/sentinel/Desktop/README.txt
echo "Management Console URL: ${URL}" >> /home/sentinel/Desktop/README.txt
echo "Logon Email: $USER_EMAIL" >> /home/sentinel/Desktop/README.txt
echo "Password: $PASSWORD" >> /home/sentinel/Desktop/README.txt
echo "" >> /home/sentinel/Desktop/README.txt
echo "Run the below command in a Terminal Window to install the S1 K8s Agent. SUDO Password: Sentinelone!" >> /home/sentinel/Desktop/README.txt
echo "sudo /home/sentinel/Scripts/install_k8s_agent.sh $SITE_TOKEN" >> /home/sentinel/Desktop/README.txt


rm /home/sentinel/Scripts/k8s_labs_config.sh
