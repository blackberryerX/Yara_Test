#!/bin/bash
# This scripts automates the steps discussed in: 
# https://support.sentinelone.com/hc/en-us/articles/1500010089601-Installing-K8s-Agents-on-Kubernetes-Endpoints

# Please provide a value for the S1_SITE_TOKEN:
S1_SITE_TOKEN=$1

# The following variable values can be customized as you see fit (or can be left as is).
S1_AGENT_TAG=ga-21.6.3 #ea-21.7.1, ga-21.5.3, etc
S1_HELPER_TAG=$S1_AGENT_TAG
REPO_SERVICE_PRINCIPAL_ID=62bc12a5-afc2-4f5c-b0cd-8bc718435eed
REPO_SERVICE_PRINCIPAL_PASSWORD=2howOQIJebR8zfj2-i_NbKShC2Bweu.s1W
REPO_BASE=s1poc.azurecr.io
REPO_HELPER=$REPO_BASE/s1helper
REPO_AGENT=$REPO_BASE/s1agent
S1_PULL_SECRET_NAME=docker-registry-s1poc
HELM_RELEASE_NAME=s1
S1_NAMESPACE=sentinelone

# Color control constants
Color_Off='\033[0m'       # Text Resets
Black='\033[0;30m'        # Black
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow
Blue='\033[0;34m'         # Blue
Purple='\033[0;35m'       # Purple
Cyan='\033[0;36m'         # Cyan
White='\033[0;37m'        # White

# Check for prerequisite binaries
if ! command -v kubectl &> /dev/null ; then
    printf "\n${Red}Missing the 'kubectl' utility.  Please install this utility and try again.\n"
	printf "Reference:  https://kubernetes.io/docs/tasks/tools/install-kubectl/\n${Color_Off}"
	exit 0
fi

if ! command -v kubectl get nodes  &> /dev/null ; then
    printf "\n${Red}Unable to issue 'kubectl get nodes' command.  Please ensure that a valid context has been established.\n"
	printf "ie: kubectl config get-context\n"
	printf "kubectl config set-context CONTEXT\n${Color_Off}"
	exit 0
fi

if ! command -v helm &> /dev/null ; then
    printf "\n${Red}Missing the 'helm' utility!  Please install this utility and try again.\n"
	printf "Reference:  https://helm.sh/docs/intro/install/\n${Color_Off}"
fi

# Get cluster name from the current context
CLUSTER_NAME=$(kubectl config view --minify -o jsonpath='{.clusters[].name}')
printf "\n${Purple}Cluster Name:  $CLUSTER_NAME\n${Color_Off}"

# Create namespace for S1 resources
printf "\n${Purple}Creating namespace...\n${Color_Off}"
kubectl create namespace ${S1_NAMESPACE}

# Create Kubernetes secret to house the credentials for accessing the container registry repos
printf "\n${Purple}Creating K8s secret ${S1_PULL_SECRET_NAME}...\n${Color_Off}"
if ! kubectl get secret ${S1_PULL_SECRET_NAME} -n ${S1_NAMESPACE} &> /dev/null ; then
	printf "\n${Purple}Creating secret for S1 image download in K8s...\n${Color_Off}"
	kubectl create secret docker-registry -n ${S1_NAMESPACE} ${S1_PULL_SECRET_NAME} \
		--docker-username="${REPO_SERVICE_PRINCIPAL_ID}" \
		--docker-server="${REPO_BASE}" \
		--docker-password="${REPO_SERVICE_PRINCIPAL_PASSWORD}"
fi

# Add the SentinelOne helm repo
printf "\n${Purple}Adding SentinelOne Helm Repo...\n${Color_Off}"
helm repo add sentinelone https://charts.sentinelone.com

# Deploy S1 agent!  Upgrade it if it already exists
printf "\n${Purple}Deploying Helm Chart...\n${Color_Off}"
helm upgrade --install ${HELM_RELEASE_NAME} --namespace=${S1_NAMESPACE} \
    --set secrets.imagePullSecret=${S1_PULL_SECRET_NAME} \
	--set secrets.site_key.value=${S1_SITE_TOKEN} \
	--set configuration.repositories.agent=${REPO_AGENT} \
	--set configuration.tag.agent=${S1_AGENT_TAG} \
	--set configuration.repositories.helper=${REPO_HELPER} \
	--set configuration.tag.helper=${S1_HELPER_TAG} \
	--set configuration.cluster.name=$CLUSTER_NAME \
	--set helper.nodeSelector."kubernetes\\.io/os"=linux \
	--set agent.nodeSelector."kubernetes\\.io/os"=linux \
	sentinelone/s1-agent

# Sleep for a few seconds to allow the images to download, untar and start.
printf "\n${Purple}Sleeping 10 seconds...\n${Color_Off}"
sleep 10

echo "Creating DVWA deployment..."

kubectl apply -f /home/sentinel/Scripts/dvwa-deploy.yaml

echo ""
echo "DVWA will be available shortly at:  http://localhost:32001"
echo ""
