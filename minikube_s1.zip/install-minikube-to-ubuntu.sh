#!/bin/bash
#
#
#         .__       .__ __        ___.
#   _____ |__| ____ |__|  | ____ _\_ |__   ____
#  /     \|  |/    \|  |  |/ /  |  \ __ \_/ __ \
# |  Y Y  \  |   |  \  |    <|  |  / \_\ \  ___/
# |__|_|  /__|___|  /__|__|_ \____/|___  /\___  >
#       \/        \/        \/         \/     \/
#
# Run with ./install-minikube-to-ubuntu.sh
#
# This script will install + start minikube on Ubuntu LTS, and Helm.
#
# After the script runs, you can point your browser to the local server:
#

MINIKUBE_VERSION="v1.22.0"
K9S_VERSION=""

function error {
  echo "${1-Fatal Error}"
  exit ${2-1}
}

echo "Getting OS version"
[ -f /etc/os-release ] || error "Could not determine OS version"

. /etc/os-release

[ "$ID" = "ubuntu" ] || error "Only supports installation in Ubuntu"
[ "$VERSION_ID" = "20.04" -o "$VERSION_ID" = "18.04" ] || error "Ubuntu ${VERSION_ID} is not supported."

# Check that user is not root
echo "Checking that you are not root"
[ ${UID} -eq 0 ] && error "This script cannot be run as root."

# Disable swap
echo "Disabling swap..."
sudo swapoff -a
sudo sed -i -r 's/^([^#].*\s+swap\s+.*)$/# Disabled because k8s: \1/' /etc/fstab

# Make changes to sysctl
echo "Making changes to sysctl"

if [ "$VERSION_ID" = "20.04" ] ; then
  # on Ubuntu 20, you need to change this differently
  echo "Using the Ubuntu 20 version of the sysctl persistent changes"
  sudo sh -c 'cat > /etc/sysctl.d/protect-links.conf' <<EOM
###################################################################
# Protected links
#
# Protects against creating or following links under certain conditions
# Debian kernels have both set to 1 (restricted) 
# See https://www.kernel.org/doc/Documentation/sysctl/fs.txt
fs.protected_fifos = 1
fs.protected_hardlinks = 1
fs.protected_regular = 0
fs.protected_symlinks = 1
EOM
  sudo sysctl --system
else
  # on Ubuntu 18, you can just write this to /etc/sysctl.conf
  echo "Using the Ubuntu 18 version of the sysctl persistent changes"
  if ! grep -q fs.protected_regular /etc/sysctl.conf; then
    sudo tee -a /etc/sysctl.conf <<EOM
    # this is needed for minikube operations with juju
fs.protected_regular = 0
EOM
    sudo sysctl --system
  fi
fi

# Install tooling and docker.io
echo "Installing packages..."
sudo apt update -y
sudo apt install -y openssh-server open-vm-tools curl liblz4-tool joe docker.io net-tools conntrack snapd
echo

# Test prerequisites
echo "Testing prerequisites..."
if sudo netstat -lntp | grep -q -E '(:443|:80)' ; then
  echo
  echo "It looks like there's something listening on port 80 or 443, which would conflict with Kubernetes Ingress. Please fix it & re-run installer script."
  echo
  echo "Sometimes this is a leftover from a previously-installed and 'removed' minikube instance; in this case, there might be a lingering instance of docker-proxy."
  echo "These are the listeners on port 80 and 443:"
  echo
  sudo netstat -lntp | grep -E '(:443|:80)'
  exit 1
fi

echo "Making changes to apt-daily-upgrade.timer"
echo " - this can sometimes break minikube, when suddenly Docker is stopped/restarted for some reason..."
sudo systemctl stop apt-daily-upgrade.timer
sudo systemctl disable apt-daily-upgrade.timer
sudo systemctl daemon-reload

# Adding user to docker group
echo "Adding user to docker group"
sudo usermod -a -G docker ${USER}

# Check user group
echo "Checking effective user group"
if ! groups | grep -q 'docker' ; then
  echo
  echo "Current user's effective groups do not include 'docker'."
  echo "The change to the user's group memberships has been made, but to make it effective, please log out and log back in."
  echo "Then re-run this script."
  exit 1
fi

# Install helm
sudo snap install --classic helm

# Install k9s, optional cmd line tool to visualize cluster state
if [ -z "$(which k9s)" ]; then
  echo "Installing K9S..."
  cd /tmp
  curl -Lo ./k9s.tgz https://github.com/derailed/k9s/releases/download/v0.17.5/k9s_Linux_x86_64.tar.gz
  tar xvzf k9s.tgz
  sudo chown root.root k9s
  sudo chmod +x k9s
  sudo cp k9s /usr/local/bin/k9s
fi

# Install kubectl
if [ -z "$(which kubectl)" ]; then
  echo "Installing kubectl..."
  curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
  sudo chmod a+x kubectl
  sudo mv kubectl /usr/local/bin/
fi

# kubectl autocompletion
echo "Adding kubectl autocompletion support for bash shell"
sudo bash <<EOM
/usr/local/bin/kubectl completion bash >/etc/bash_completion.d/kubectl
EOM

function install_minikube {
  echo " - Installing minikube..."
  cd /tmp
  #    curl -Lo minikube https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
  curl -Lo minikube https://github.com/kubernetes/minikube/releases/download/${MINIKUBE_VERSION}/minikube-linux-amd64
  sudo chmod +x minikube
  sudo mv -f minikube /usr/local/bin
}

# Install minikube
echo "Checking for minikube..."
if [ -z $(which minikube) ]; then
  echo " - minikube is not present"
  install_minikube
else
  if ! minikube version | grep -q ${MINIKUBE_VERSION} ; then
    echo " - there is a minikube, but it is the wrong version."
    install_minikube
  else
    echo " - minikube is the right version"
  fi
fi

# Get configuration values
# DASHBOARD_URL_DEFAULT=$(hostname -f)
# echo "What's the hostname you would like to use for the Kubernetes dashboard? (${DASHBOARD_URL_DEFAULT})?"
# echo "This MUST be an FQDN (host.some.domain), and needs to resolve to the IP address of this system."
# echo "Every application you publish should use a dedicated FQDN." 
# read DASHBOARD_URL


# Start minikube with docker
if ! sudo minikube status &>/dev/null; then
  echo "Starting minikube..."
  export CHANGE_MINIKUBE_NONE_USER=true
  sudo -E minikube config set driver none
  # sudo -E minikube config set cpus 4
  # sudo -E minikube config set memory 30000
  sudo -E minikube start --extra-config=apiserver.service-node-port-range=1-65535
  # sudo mv /root/.kube /root/.minikube $HOME
  # sudo chown -R $USER:$GROUP $HOME/.kube $HOME/.minikube
  # exit
  sudo -E minikube addons enable metrics-server
  sudo -E minikube addons enable dashboard
  sudo -E minikube addons enable ingress
fi

# wait a while for the deployment to be finished
until kubectl get svc kubernetes-dashboard -n kubernetes-dashboard &>/dev/null; do
  echo "Waiting for the kubernetes-dashboard service to come alive..."
  sleep 5
done


# override the default kubernetes-dashboard service definition to expose it on port 8080
kubectl apply -f - <<EOM
apiVersion: v1
kind: Service
metadata:
  labels:
    addonmanager.kubernetes.io/mode: EnsureExists
    k8s-app: kubernetes-dashboard
    kubernetes.io/minikube-addons: dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
  selfLink: /api/v1/namespaces/kubernetes-dashboard/services/kubernetes-dashboard
spec:
  externalTrafficPolicy: Cluster
  ports:
  - nodePort: 32000
    port: 80
    protocol: TCP
    targetPort: 9090
  selector:
    k8s-app: kubernetes-dashboard
  sessionAffinity: None
  type: NodePort
status:
  loadBalancer: {}
EOM

echo "Waiting for Kubernetes Ingress Controller admission (validation) webhooks to become available (will wait up to 180s to accomodate the slowest of the slow laptops and VMs on them...)"
# see here: https://kubernetes.github.io/ingress-nginx/deploy/
kubectl wait --namespace ingress-nginx \
	--for=condition=ready pod \
	--selector=app.kubernetes.io/component=controller,app.kubernetes.io/instance=ingress-nginx \
	--timeout=120s
kubectl wait --namespace ingress-nginx \
	--for=condition=complete job.batch/ingress-nginx-admission-create \
	--timeout 180s
kubectl wait --namespace ingress-nginx \
	--for=condition=complete job.batch/ingress-nginx-admission-patch \
	--timeout 180s
kubectl wait --namespace ingress-nginx \
	--for=condition=ready pod \
	--selector=app.kubernetes.io/component=controller,app.kubernetes.io/instance=ingress-nginx \
	--timeout=180s

kubectl apply -f - <<EOM
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
  labels:
    k8s-app: kubernetes-dashboard
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /\$2
    nginx.ingress.kubernetes.io/app-root: /dashboard/
spec:
  rules:
  - http:
      paths:
      - path: /dashboard(/|$)(.*)
        pathType: ImplementationSpecific
        backend:
          service:
            name: kubernetes-dashboard
            port:
              number: 9090
EOM

cat <<EOM
Done!

You should now be able to access the Kubernetes dashboard at http://<this system>/dashboard/

To uninstall/start/stop, use these commands:

minikube start
minikube stop
minikube delete

NOTE: 

* For anything else, you can use kubectl or k9s on this system. You should REALLY try k9s if you are not familiar with kubectl.
  - some interesting hotkeys to remember are 'l' and 's', the number keys, ctrl-c to exit, ctrl-a to pick an object type to show, and 'y' to look at a YAML version of an object
* Shell auto-completion has been enabled in the bash shell for kubectl. You may need to restart your shell (log out/log in) to take advantage of the auto-completion features.
* To enable AUTOMATIC START-UP at boot, run 'sudo systemctl enable kubelet.service'
EOM

