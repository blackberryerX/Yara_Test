#!/bin/bash

echo "Creating DVWA deployment..."

kubectl apply -f dvwa-deploy.yaml

echo ""
echo "DVWA will be available shortly at:  http://localhost:32001"
echo ""

